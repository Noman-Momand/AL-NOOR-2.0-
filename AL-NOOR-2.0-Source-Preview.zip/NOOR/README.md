# Al Noor 0.3.0
Native Android Quran and Islamic companion by Noman Momand, Aryan Info-Tech. Requires Android 8 or newer.

## On your phone
Open **Language** on Today to select English or پښتو. This changes navigation, reading meanings, date labels, notifications and the full Hisn edition. The Arabic originals remain available in both languages. Choose **Recite the Quran** for framed pages or **Quran with translation** for individual ayahs and publisher notes.

Swipe right to advance a Quran page, swipe left to return, or tap **Next** and **Previous**. Both gestures and buttons use the same optional page rustle. Size, colour, bookmark, translation and sound controls appear below the page. Open **Hisn al-Muslim** to search the 132 chapters or resume the original published book. Each chapter has a link to its matching page in the selected language.

**Digital Tasbeeh** has separate counts for three phrases. Choose **Choose backup file** and save in local Documents to keep an uninstall-resistant copy. After reinstalling choose **Restore from file** and select that document. Daily chapter counters are separate and reset each day.

## Open the source
Extract the project ZIP. In Android Studio choose **Open** and select the folder containing settings.gradle.kts. Select JDK 17 for Gradle and install Android SDK Platform 35. Sync, choose a device, then Run. First-time development builds download dependencies. Installed reading features work entirely offline.

From the project root run:

```sh
python3 tools/verify_content.py
./gradlew :app:testDebugUnitTest :app:assembleDebug
```

On Windows use gradlew.bat. The APK appears under app/build/outputs/apk/debug/. To build from a phone using GitHub, put the **extracted project contents** at the root of your own repository, including the .github directory. Open Actions → Build NOOR APK → Run workflow, then download the NOOR-debug-apk artifact. GitHub wraps the APK in a ZIP.

## Inside the project
- docs/DEVELOPMENT.md explains the scope, architecture, feature contracts, release stages and acceptance tests.
- docs/STRUCTURE.md maps the actual source tree and gives editing entry points.
- docs/CONTENT.md records publisher editions, terms and remaining editorial checks.
- app/src/main/assets holds the complete offline library, source metadata and credits.
- tools/verify_content.py checks hashes and every verse pair. app/src/test holds Android JVM tests.


The debug application ID is af.aryaninfo.noor.preview2. The release application ID is af.aryaninfo.noor. The Play Store release still requires content rights confirmation, editorial review, device testing and release signing.

## AL NOOR 2.0 preview
See [upgrade notes and known limitations](docs/UPGRADE-2.0.md) before building or releasing.
