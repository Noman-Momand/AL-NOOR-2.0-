plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "af.aryaninfo.noor"
    compileSdk = 35
    defaultConfig {
        applicationId = "af.aryaninfo.noor"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "2.0.0-preview"
    }
    buildTypes { getByName("debug") { applicationIdSuffix = ".preview2" } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    testOptions { unitTests.isIncludeAndroidResources = true }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("com.batoulapps.adhan:adhan:1.2.1")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.robolectric:robolectric:4.14.1")
}
