package af.aryaninfo.noor

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import java.time.LocalDate
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], qualifiers = "w390dp-h844dp")
class OfflineTest {
    @Test
    fun everyAyahAndChapterLoadsFromThePackagedFiles() {
        val catalog = Catalog.load(RuntimeEnvironment.getApplication())
        assertEquals(6236, catalog.surahs.sumOf { it.verses.size })
        assertEquals(132, catalog.chapters.size)
        assertEquals(267, catalog.chapters.sumOf { it.entries.size })
        repeat(62) { offset ->
            val (s, a) = dailyVerse(LocalDate.of(2026, 1, 1).plusDays(offset.toLong()))
            val verse = catalog.surahs[s - 1].verses[a - 1]
            assertTrue(verse.arabic.isNotBlank() && verse.pashto.isNotBlank())
        }
    }

    @Test
    fun readerAndCompanionScreensUseLocalData() {
        val ctx = RuntimeEnvironment.getApplication() as Context
        val data = Catalog.load(ctx)
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        val activity = controller.get()
        activity.catalog = data
        fun texts(view: View): List<String> =
            when (view) {
                is TextView -> listOf(view.text.toString())
                is ViewGroup -> (0 until view.childCount).flatMap { texts(view.getChildAt(it)) }
                else -> emptyList()
            }
        val expected =
            mapOf(
                "home" to "AYAH OF THE DAY",
                "reader" to data.surahs[0].verses[0].english,
                "adhkar" to "Hisn al-Muslim",
                "chapter" to data.chapters[26].title,
                "prayer" to "Qibla",
                "calendar" to "Islamic calendar",
                "legal" to "Privacy policy",
                "settings" to "Daily recitation",
                "tas" to "Digital Tasbeeh",
            )
        for ((route, caption) in expected) {
            activity.go(route)
            assertTrue("Missing $caption on $route", texts(activity.root).contains(caption))
        }
        controller.pause().stop().destroy()
    }

    @Test
    fun deliveredAyahAndRecitationOpenDifferentReferences() {
        val ctx: Context = RuntimeEnvironment.getApplication()
        val catalog = Catalog.load(ctx)
        val prefs = ctx.getSharedPreferences("noor", Context.MODE_PRIVATE)
        prefs.edit().putInt("surah", 114).putInt("ayah", 6).commit()
        fun launch(kind: String): Pair<MainActivity, List<String>> {
            val intent =
                android.content
                    .Intent(ctx, MainActivity::class.java)
                    .putExtra("destination", kind)
                    .putExtra("surah", 94)
                    .putExtra("ayah", 5)
            val activity = Robolectric.buildActivity(MainActivity::class.java, intent).setup().get()
            activity.catalog = catalog
            activity.render()
            fun collect(v: View): List<String> =
                when (v) {
                    is TextView -> listOf(v.text.toString())
                    is ViewGroup -> (0 until v.childCount).flatMap { collect(v.getChildAt(it)) }
                    else -> emptyList()
                }
            return activity to collect(activity.root)
        }
        val (daily, dayText) = launch("ayah")
        assertTrue(dayText.contains(catalog.surahs[93].verses[4].english))
        daily.finish()
        val (reader, readingText) = launch("recite")
        assertTrue(readingText.contains(catalog.surahs[113].verses[5].arabic))
        reader.finish()
    }

    @Test
    fun disablingAdhkarKeepsTheOtherAlarms() {
        val ctx: Context = RuntimeEnvironment.getApplication()
        val prefs = ctx.getSharedPreferences("noor", Context.MODE_PRIVATE)
        DailyReminder.types.forEach {
            prefs
                .edit()
                .putBoolean("enabled/$it", true)
                .putInt("hour/$it", 8)
                .putInt("minute/$it", 0)
                .commit()
        }
        DailyReminder.schedule(ctx)
        val alarms =
            org.robolectric.Shadows.shadowOf(
                ctx.getSystemService(android.app.AlarmManager::class.java)
            )
        assertEquals(3, alarms.scheduledAlarms.size)
        prefs.edit().putBoolean("enabled/adhkar", false).commit()
        DailyReminder.schedule(ctx, "adhkar")
        assertEquals(2, alarms.scheduledAlarms.size)
    }
}
