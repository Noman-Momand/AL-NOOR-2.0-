package af.aryaninfo.noor

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import java.time.LocalDate
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.*
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], qualifiers = "w390dp-h844dp")
class ReaderUpdateTest {
    val ctx: Context
        get() = RuntimeEnvironment.getApplication()

    @Test
    fun everyPageAndJuzPreservesItsPublishedBoundary() {
        val c = Catalog.load(ctx)
        val map = PageMap(ctx)
        val refs =
            (1..604).flatMap { page ->
                val rows = map.refs(page, c)
                assertEquals(map.pages[page - 1], rows.first())
                assertTrue(rows.all { map.page(it) == page })
                rows
            }
        assertEquals(c.surahs.flatMap { s -> s.verses.indices.map { Ref(s.id, it + 1) } }, refs)
        map.parts.forEachIndexed { i, r -> assertEquals(i + 1, map.juz(r)) }
        assertEquals(604, map.page(Ref(114, 6)))
    }

    @Test
    fun cacheSurvivesReopenAndRejectsWrongDayOrMethod() {
        val body =
            javaClass.getResourceAsStream("/aladhan-kabul.json")!!.bufferedReader().use {
                it.readText()
            }
        val day = "20-11-2026"
        val zone = "Asia/Kabul"
        val result = timetableResponse(body, day, zone, 1)
        assertEquals("15:08", result.getString("Asr"))
        assertTrue(runCatching { timetableResponse(body, "21-11-2026", zone, 1) }.isFailure)
        assertTrue(runCatching { timetableResponse(body, day, zone, 4) }.isFailure)
        Timetables(ctx).use { it.store("kabul", LocalDate.of(2026, 11, 20), result) }
        Timetables(ctx).use {
            assertEquals("05:04", it.read("kabul")!!.getString("Fajr"))
            assertNull(it.read("another-location"))
        }
    }

    @Test
    fun recitationAndLearningSectionsOpen() {
        val ctl = Robolectric.buildActivity(MainActivity::class.java).setup()
        val a = ctl.get()
        a.catalog = Catalog.load(ctx)
        fun all(v: View): List<View> =
            listOf(v) +
                if (v is ViewGroup) (0 until v.childCount).flatMap { all(v.getChildAt(it)) }
                else emptyList()
        a.go("mushaf")
        val next = all(a.root).filterIsInstance<TextView>().first { it.text == "Next" }
        next.performClick()
        assertEquals(2, a.prefs.getInt("mushafPage", 0))
        assertTrue(
            all(a.root).filterIsInstance<TextView>().any {
                it.text.contains(opening(Ref(2, 1), a.catalog.surahs[1].verses[0].arabic))
            }
        )
        a.openTranslation(2, 1)
        assertTrue(
            all(a.root).filterIsInstance<TextView>().any {
                it.text.toString() == a.catalog.surahs[1].verses[0].english
            }
        )
        for ((route, text) in
            mapOf(
                "salah" to "Final sitting and salam",
                "wudu" to "6. Wash both feet",
                "founder" to "Noman Momand",
                "occasions" to "Afternoon",
                "juz" to "Juz 30",
                "bookmarks" to "Bookmarks",
            )) {
            a.go(route)
            assertTrue(route, all(a.root).filterIsInstance<TextView>().any { it.text == text })
        }
        ctl.pause().stop().destroy()
    }

    @Test
    @org.robolectric.annotation.GraphicsMode(org.robolectric.annotation.GraphicsMode.Mode.NATIVE)
    fun defaultPageFitsPortraitViewport() {
        val ctl = Robolectric.buildActivity(MainActivity::class.java).setup()
        val a = ctl.get()
        a.catalog = Catalog.load(ctx)
        a.prefs.edit().putInt("mushafPage", 400).commit()
        a.go("mushaf")
        val root = a.root
        repeat(3) {
            root.measure(
                View.MeasureSpec.makeMeasureSpec(390, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(800, View.MeasureSpec.EXACTLY),
            )
            root.layout(0, 0, 390, 800)
        }
        val scroll = (root.getChildAt(2) as ViewGroup).getChildAt(0) as android.widget.ScrollView
        val text = scroll.getChildAt(0) as TextView
        assertTrue("Quran text visible", text.textSize > 10 && text.layout.lineCount > 3)
        assertTrue("Every line is visible", text.layout.height <= text.height + 2)
        assertTrue(
            "Whole page fits",
            text.height <= scroll.height - scroll.paddingTop - scroll.paddingBottom + 2,
        )
        ctl.pause().stop().destroy()
    }

    @Test
    fun languageSelectsBothEditionsAndReaderControls() {
        val ctl = Robolectric.buildActivity(MainActivity::class.java).setup()
        val a = ctl.get()
        a.catalog = Catalog.load(ctx)
        fun captions(v: View): List<String> =
            when (v) {
                is TextView -> listOf(v.text.toString())
                is ViewGroup -> (0 until v.childCount).flatMap { captions(v.getChildAt(it)) }
                else -> emptyList()
            }
        for (pashto in listOf(false, true)) {
            a.prefs.edit().putString("language", if (pashto) "ps" else "en").commit()
            val v = a.catalog.surahs[0].verses.first()
            a.openTranslation(1, 1)
            assertTrue(captions(a.root).contains(if (pashto) v.pashto else v.english))
            a.go("mushaf")
            val ui = captions(a.root)
            for (caption in
                if (pashto) listOf("کوچنی −", "لوی +", "رنګ", "نښه", "غږ فعال")
                else listOf("Size −", "Size +", "Colour", "Bookmark", "Sound on")) assertTrue(
                caption,
                caption in ui,
            )
            a.chapter = 27
            a.go("chapter")
            assertTrue(captions(a.root).contains(a.chapterName(a.catalog.chapters[26])))
            assertTrue(
                captions(a.root)
                    .contains(
                        if (pashto) "دا څپرکی په پښتو ولولئ" else "Read this chapter in English"
                    )
            )
        }
        ctl.pause().stop().destroy()
    }

    @Test
    fun surahOpeningsPreserveEveryWordAndTwiceIndexedHisnEntriesAreRejected() {
        val catalog = Catalog.load(ctx)
        for (s in catalog.surahs) {
            val original = s.verses.first().arabic
            val layout = opening(Ref(s.id, 1), original)
            assertEquals(original, layout.replace("\n\n", " "))
            assertEquals(s.id !in listOf(1, 9), layout.contains("\n\n"))
        }
        assertEquals(
            (1..267).toList(),
            catalog.chapters.flatMap { c -> c.entries.map { it.id } }.sorted(),
        )
        assertEquals(197, catalog.chapters[85].entries.first().id)
    }

    @Test
    fun counterAcceptsTapsSwipesAndCompleteBackupRecords() {
        val ctl = Robolectric.buildActivity(MainActivity::class.java).setup()
        val a = ctl.get()
        a.catalog = Catalog.load(ctx)
        a.go("tas")
        fun views(v: View): List<View> =
            listOf(v) +
                if (v is ViewGroup) (0 until v.childCount).flatMap { views(v.getChildAt(it)) }
                else emptyList()
        fun button(name: String) =
            views(a.root).filterIsInstance<TextView>().first { it.text.toString() == name }
        button("Tap to count").performClick()
        button("Switch to swipe beads").performClick()
        val beads = views(a.root).first { it.contentDescription == "Tasbeeh count" }
        beads.layout(0, 0, 400, 250)
        for ((kind, x) in
            listOf(
                android.view.MotionEvent.ACTION_DOWN to 20f,
                android.view.MotionEvent.ACTION_UP to 230f,
            )) {
            val event = android.view.MotionEvent.obtain(0L, 20L, kind, x, 120f, 0)
            beads.onTouchEvent(event)
            event.recycle()
        }
        assertEquals(2L, a.prefs.getLong("tas/0", 0))
        assertEquals(
            listOf(2L, 7L, 0L),
            counterValues("""{"format":"al-noor-tasbeeh-1","n0":2,"n1":7,"n2":0}"""),
        )
        assertNull(counterValues("{"))
        ctl.pause().stop().destroy()
    }
}
