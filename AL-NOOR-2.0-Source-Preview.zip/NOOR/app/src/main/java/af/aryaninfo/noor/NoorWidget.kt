package af.aryaninfo.noor

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class NoorWidget: AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val (s,a)=dailyVerse()
        for(id in ids) {
            val views=RemoteViews(context.packageName,R.layout.noor_widget)
            views.setTextViewText(R.id.widget_ayah,context.t4("Daily ayah", "د نن آیت", "آیه روز", "آية اليوم")+" · $s:$a")
            val intent=Intent(context,MainActivity::class.java).putExtra("destination","ayah").putExtra("surah",s).putExtra("ayah",a)
            views.setOnClickPendingIntent(R.id.widget_root,PendingIntent.getActivity(context,id,intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            manager.updateAppWidget(id,views)
        }
    }
}
