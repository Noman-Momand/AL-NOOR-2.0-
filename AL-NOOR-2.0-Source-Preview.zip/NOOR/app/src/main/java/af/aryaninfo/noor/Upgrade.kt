package af.aryaninfo.noor

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.view.*
import android.widget.*
import com.batoulapps.adhan.*
import com.batoulapps.adhan.data.DateComponents
import java.time.*
import java.time.format.DateTimeFormatter
import kotlin.math.*

private data class Palette(val name: String, val bg: Long, val card: Long, val fg: Long, val secondary: Long, val accent: Long, val hero: Long, val control: Long, val dark: Boolean)
private val palettes = listOf(
    Palette("Lunar Gold",0xff20170f,0xff392a1f,0xffffe9c6,0xffd7c4a7,0xffedc482,0xff392a1f,0xff59432e,true),
    Palette("Midnight OLED",0xff080808,0xff1c1c1e,0xfff7f7f7,0xffb9b9bf,0xffd8b77a,0xff1c1c1e,0xff343438,true),
    Palette("Pearl White",0xfff1f2f4,0xffffffff,0xff161616,0xff565b63,0xffe4c486,0xff34383e,0xffe4e6e9,false),
    Palette("Royal Emerald",0xff102d25,0xff204b3b,0xfff1e9cf,0xffd3decf,0xfff0d9a2,0xff204b3b,0xff36594a,true),
    Palette("Classic Manuscript",0xffe9d9ba,0xfff5e8cc,0xff483521,0xff6b5134,0xffedcb91,0xff62482c,0xffdfc8a3,false),
    Palette("Celestial Blue",0xff10192d,0xff243957,0xffe1e8ff,0xffbdc9e1,0xffe7d4a6,0xff243957,0xff3a506f,true)
)
internal fun Screen.applyPalette() {
    val p = getSharedPreferences("noor",0)
    val index = if(p.getBoolean("autoTheme",false)) {
        if ((resources.configuration.uiMode and 0x30) == 0x20) 1 else 2
    } else p.getInt("themeV2",0).coerceIn(0,5)
    val x = palettes[index]
    paper=x.bg.toInt(); surfaceColor=x.card.toInt(); ink=x.fg.toInt(); muted=x.secondary.toInt(); gold=x.accent.toInt(); heroColor=x.hero.toInt(); controlColor=x.control.toInt(); darkPalette=x.dark
}
fun MainActivity.themeScreen() {
    begin(t4("Appearance","بڼه","ظاهر","المظهر"),t4("Choose your theme","خپله بڼه وټاکئ","تم خود را انتخاب کنید","اختر السمة"),t4("Six distinct palettes","شپږ رنګونه","شش تم متفاوت","ست سمات مختلفة"))
    val auto = card()
    auto.addView(Switch(this).apply { text=t4("Follow system day/night","د سیستم رڼا او تیاره","مطابق حالت روز و شب سیستم","اتباع الوضع الفاتح والداكن");setTextColor(ink);isChecked=prefs.getBoolean("autoTheme",false);setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("autoTheme",v).apply();render() } })
    palettes.forEachIndexed { i,p ->
        val c=card(); val sw=LinearLayout(this);c.addView(sw)
        listOf(p.bg,p.card,p.accent,p.fg).forEach { x -> sw.addView(View(this).apply {setBackgroundColor(x.toInt())},LinearLayout.LayoutParams(0,dp(28),1f)) }
        action(c,p.name+(if(prefs.getInt("themeV2",0)==i && !prefs.getBoolean("autoTheme",false)) "  ✓" else "")) { prefs.edit().putInt("themeV2",i).putBoolean("autoTheme",false).apply();render() }
    }
}
fun MainActivity.openPublisher() { startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://quranenc.com/prs/browse/dari_badkhashani"))) }
fun Context.editionCredit() = when(translationLanguage) { "ps" -> "Rowwad Translation Center · QuranEnc 1.0.1"; "prs" -> "محمد انور بدخشانی · QuranEnc 1.0.0"; "ar" -> "Tanzil · Uthmani 1.1"; else -> "Noor International Center · QuranEnc 1.1.2" }
fun MainActivity.translationMenu() {
    val ids=listOf("auto","en","ps","prs","ar")
    AlertDialog.Builder(this).setTitle(t4("Translation edition","د ژباړې چاپ","نسخه ترجمه","نسخة الترجمة")).setSingleChoiceItems(arrayOf(t4("Match interface","د ژبې سره","مطابق زبان برنامه","لغة الواجهة"),"English","پښتو","دری",t4("Arabic only","یوازې عربي","فقط عربی","العربية فقط")),ids.indexOf(prefs.getString("translationLanguage","auto"))) { d,i -> prefs.edit().putString("translationLanguage",ids[i]).apply();d.dismiss();render() }.show()
}
private data class Slot(val name:String,val at:Instant)
private fun MainActivity.slots(date:LocalDate): List<Slot> {
    val p=city(); val method=CalculationMethod.valueOf(prefs.getString("method","KARACHI")!!)
    val t=PrayerTimes(Coordinates(p.lat,p.lon),DateComponents(date.year,date.monthValue,date.dayOfMonth),method.parameters.apply { madhab=Madhab.HANAFI })
    return listOf("Fajr" to t.fajr,"Sunrise" to t.sunrise,"Dhuhr" to t.dhuhr,"Asr" to t.asr,"Maghrib" to t.maghrib,"Isha" to t.isha).map { Slot(it.first,it.second.toInstant()) }
}
private fun MainActivity.nextSlot(now:Instant):Slot? = runCatching {
    val date=now.atZone(city().zone).toLocalDate()
    (slots(date)+slots(date.plusDays(1))).firstOrNull { it.name!="Sunrise" && it.at>now }
}.getOrNull()
private fun durationText(seconds:Long):String { val n=seconds.coerceAtLeast(0);return "%02d:%02d:%02d".format(java.util.Locale.ROOT,n/3600,n/60%60,n%60) }
private fun MainActivity.clockFormatter() = DateTimeFormatter.ofPattern("HH:mm").withZone(city().zone)
private class LiveClock(context:Context, private val update:(TextView)->Unit):TextView(context) {
    private val ticker=object:Runnable { override fun run() { if(isAttachedToWindow){update(this@LiveClock);postDelayed(this,1000)} } }
    override fun onAttachedToWindow(){super.onAttachedToWindow();removeCallbacks(ticker);ticker.run()}
    override fun onDetachedFromWindow(){removeCallbacks(ticker);super.onDetachedFromWindow()}
}
private class MoonArt(context:Context,private val phase:Double):View(context) {
    private val p=Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c:Canvas){
        val x=width/2f; val y=height/2f; val r=min(x,y)*.72f
        if(r<=0)return
        p.shader=RadialGradient(x,y,r*1.4f,intArrayOf(0x55edc482,0x00edc482),null,Shader.TileMode.CLAMP); c.drawCircle(x,y,r*1.4f,p)
        p.shader=RadialGradient(x-r*.25f,y-r*.3f,r*1.3f,intArrayOf(0xfffff4cb.toInt(),0xffc49b61.toInt()),null,Shader.TileMode.CLAMP);c.drawCircle(x,y,r,p);p.shader=null
        p.color=0x1b654c27
        for(i in 0..22){val a=i*2.39996;val d=r*.80*sqrt((i+1)/23.0); c.drawCircle(x+(cos(a)*d).toFloat(),y+(sin(a)*d).toFloat(),r*(.035f+(i%5)*.024f),p)}
        // A visual phase approximation; not an observational crescent prediction.
        val lit=(1-cos(phase*2*PI))/2; val widthShadow=(2*r*(1-lit)).toFloat()
        if(widthShadow>0){c.save();val clip=Path();clip.addCircle(x,y,r,Path.Direction.CW);c.clipPath(clip);p.color=0xaa19140f.toInt();if(phase<.5)c.drawOval(x-r,y-r,x-r+widthShadow,y+r,p) else c.drawOval(x+r-widthShadow,y-r,x+r,y+r,p);c.restore()}
    }
}
private class Dial(context:Context):View(context){var progress=0f; private val p=Paint(Paint.ANTI_ALIAS_FLAG);override fun onDraw(c:Canvas){val x=width/2f;val y=height/2f;val r=min(x,y)*.82f;p.style=Paint.Style.STROKE;p.strokeWidth=5f;p.color=controlColor;c.drawCircle(x,y,r,p);p.color=gold;c.drawArc(x-r,y-r,x+r,y+r,-90f,360f*progress.coerceIn(0f,1f),false,p);p.strokeWidth=2f;for(i in 0..59){val a=i*PI/30;val k=if(i%5==0) .78 else .84;c.drawLine(x+(cos(a)*r*k).toFloat(),y+(sin(a)*r*k).toFloat(),x+(cos(a)*r*.92).toFloat(),y+(sin(a)*r*.92).toFloat(),p)};p.style=Paint.Style.FILL}}
fun MainActivity.prayerSummary(c:LinearLayout) {
    val modes=listOf("Circular","Minimal","Timeline")
    val mode=prefs.getInt("prayerLayout",0).coerceIn(0,2)
    action(c,t4("Prayer layout","د لمانځه بڼه","نمایش اوقات نماز","تصميم أوقات الصلاة")+" · "+modes[mode]) { AlertDialog.Builder(this).setItems(modes.toTypedArray()){_,i->prefs.edit().putInt("prayerLayout",i).apply();render()}.show() }
    val frame=FrameLayout(this);c.addView(frame,LinearLayout.LayoutParams(-1,dp(if(mode==0) 180 else 95)))
    val dial=if(mode==0) Dial(this).also {frame.addView(it,FrameLayout.LayoutParams(-1,-1))} else null
    var cached:Slot?=null
    var previous:Instant?=null
    val clock=LiveClock(this){v-> val now=Instant.now();if(cached==null || !cached!!.at.isAfter(now)) {cached=nextSlot(now);previous=runCatching{val date=now.atZone(city().zone).toLocalDate();(slots(date.minusDays(1))+slots(date)).lastOrNull{it.name!="Sunrise" && it.at<=now}?.at}.getOrNull()};val s=cached;val prev=previous;if(s!=null && prev!=null){dial?.progress=(Duration.between(prev,now).seconds.toFloat()/Duration.between(prev,s.at).seconds.coerceAtLeast(1));dial?.invalidate()};v.text=if(s==null) l("Unavailable","وخت نشته") else placeLabel(s.name)+"\n"+durationText(Duration.between(now,s.at).seconds) }
    clock.textSize=26f;clock.gravity=Gravity.CENTER;clock.setTextColor(ink);frame.addView(clock,FrameLayout.LayoutParams(-1,-1))
    val today=runCatching{slots(LocalDate.now(city().zone))}.getOrDefault(emptyList())
    if(mode==2)today.forEach { c.addView(label(placeLabel(it.name)+"  ·  "+clockFormatter().format(it.at),18)) }
    else { val row=LinearLayout(this); c.addView(row);today.filter {it.name!="Sunrise"}.forEach { row.addView(label(placeLabel(it.name)+"\n"+clockFormatter().format(it.at),12).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(0,-2,1f)) } }
    c.addView(label(t4("Offline calculated times · Hanafi Asr","حساب شوي وختونه · حنفي عصر","اوقات محاسبه‌شده · عصر حنفی","أوقات محسوبة · العصر الحنفي"),12,muted))
}
fun MainActivity.ambientScreen() {
    begin("AL NOOR",t4("Ambient clock","د سپوږمۍ ساعت","ساعت مهتابی","ساعة القمر"),city().name)
    val c=card(); val days=Duration.between(Instant.parse("2000-01-06T18:14:00Z"),Instant.now()).seconds/86400.0;val phase=((days/29.530588853)%1+1)%1
    c.addView(MoonArt(this,phase),LinearLayout.LayoutParams(-1,dp(240)))
    val clock=LiveClock(this){it.text=clockFormatter().format(Instant.now())};clock.gravity=Gravity.CENTER;clock.textSize=56f;clock.setTextColor(ink);c.addView(clock)
    c.addView(label(LocalDate.now(city().zone).toString()+"  ·  "+hijri(LocalDate.now(city().zone)),16).apply{gravity=Gravity.CENTER})
    c.addView(label(t4("Illustrative lunar phase, not a sighting","د سپوږمۍ اټکلي بڼه","نمای تقریبی ماه؛ نه رؤیت هلال","طور قمري تقريبي، لا يمثل الرؤية"),12,muted))
    prayerSummary(card())
    action(card(),t4("Evening supplications","د ماښام اذکار","اذکار شام","أذكار المساء")){chapter=27;go("chapter")}
    val brightness=card()
    val level=SeekBar(this).apply {max=100;progress=60;setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onStartTrackingTouch(bar:SeekBar){};override fun onStopTrackingTouch(bar:SeekBar){};override fun onProgressChanged(bar:SeekBar,value:Int,fromUser:Boolean){window.attributes=window.attributes.apply{screenBrightness=(value/100f).coerceIn(.05f,1f)}}})}
    brightness.addView(label(t4("Screen brightness","د سکرین رڼا","روشنایی صفحه","سطوع الشاشة"),18));brightness.addView(level)
    action(brightness,t4("Full screen","بشپړ سکرین","تمام صفحه","ملء الشاشة")){window.decorView.systemUiVisibility=window.decorView.systemUiVisibility or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION}
    brightness.addView(label(t4("Keep screen awake","سکرین روښانه وساتئ","صفحه روشن بماند","إبقاء الشاشة مضاءة"),18))
    brightness.addView(Switch(this).apply {isChecked=false;setOnCheckedChangeListener {_,v-> if(v)window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)}})
}
fun MainActivity.ramadanScreen(){
    begin(t4("Worship","عبادت","عبادت","العبادة"),t4("Ramadan studio","د رمضان برخه","بخش رمضان","ركن رمضان"),t4("Daily fasting planner","د روژې پلان","برنامه روزه","مخطط الصيام"))
    val c=card();val date=LocalDate.now(city().zone);val today=runCatching{slots(date)}.getOrDefault(emptyList());val tomorrow=runCatching{slots(date.plusDays(1))}.getOrDefault(emptyList());val targets=(today+tomorrow).filter{it.name in listOf("Fajr","Maghrib")}
    targets.take(2).forEach {c.addView(label((if(it.name=="Fajr")t4("Fajr (end of suhoor)","سهار (د پېشلمي پای)","صبح (پایان سحری)","الفجر (نهاية السحور)") else t4("Maghrib (iftar)","ماښام (روژه ماتې)","شام (افطار)","المغرب (الإفطار)"))+" · "+clockFormatter().format(it.at),18))}
    c.addView(LiveClock(this){v->val now=Instant.now();val next=targets.firstOrNull{it.at>now};v.text=if(next==null)"—" else placeLabel(next.name)+"  "+durationText(Duration.between(now,next.at).seconds)}.apply{textSize=28f;setTextColor(ink)})
    c.addView(label(t4("Check local mosque timings and Ramadan dates.","د جومات وختونه وګورئ.","اوقات مسجد و تاریخ رمضان را بررسی کنید.","تحقق من توقيت المسجد وتاريخ رمضان."),14,muted))
    val goal=card(); goal.addView(CheckBox(this).apply {text=t4("Record fast completed today","نن روژه بشپړه شوه","روزه امروز را ثبت کنید","تسجيل صيام اليوم");setTextColor(ink);isChecked=prefs.getBoolean("fast/$date",false);setOnCheckedChangeListener{_,v->prefs.edit().putBoolean("fast/$date",v).apply()}})
    action(goal,t4("Hijri calendar","هجري کلیز","تقویم هجری","التقويم الهجري")){go("calendar")};action(goal,t4("Quran goals","د قرآن موخې","اهداف قرآن","أهداف القرآن")){go("memorize")}
}
fun MainActivity.journalScreen(){
    val date=LocalDate.now(city().zone);begin("AL NOOR",t4("Private journal","شخصي یادښت","یادداشت شخصی","مذكرات خاصة"),date.toString());val c=card();val f=EditText(this).apply{setTextColor(ink);setHintTextColor(muted);hint=t4("Your reflection","خپل یادښت","یادداشت شما","تأملاتك");minLines=5;setText(prefs.getString("journal/$date",""))};c.addView(f);action(c,t4("Save on device","په موبایل کې ساتل","ذخیره در دستگاه","حفظ على الجهاز")){prefs.edit().putString("journal/$date",f.text.toString()).apply();Toast.makeText(this,t4("Saved","وساتل شو","ذخیره شد","تم الحفظ"),Toast.LENGTH_SHORT).show()}
    val history=card();prefs.all.keys.filter{it.startsWith("journal/")&&it!="journal/$date"}.sortedDescending().forEach{key->history.addView(label(key.substringAfter('/')+"\n"+prefs.getString(key,""),16))}
}
fun MainActivity.memorizeScreen(){
    begin("AL NOOR",t4("Memorization & goals","حفظ او موخې","حفظ و اهداف","الحفظ والأهداف"),t4("Track your own progress","خپل پرمختګ ثبت کړئ","پیشرفت خود را ثبت کنید","تابع تقدمك"))
    val c=card();val input=EditText(this).apply{inputType=2;setTextColor(ink);setText(prefs.getInt("dailyGoal",5).toString())};c.addView(label(t4("Daily ayah goal","ورځنۍ آیت موخه","هدف روزانه آیات","هدف الآيات اليومي"),18));c.addView(input);action(c,l("Save","وساتئ")){val n=input.text.toString().toIntOrNull();if(n!=null&&n in 1..6236){prefs.edit().putInt("dailyGoal",n).apply();render()}else input.error="1–6236"}
    val progress=card(); val date=LocalDate.now(city().zone);val count=prefs.getInt("memorized/$date",0);progress.addView(label("$count / ${prefs.getInt("dailyGoal",5)}",30));action(progress,t4("Record one ayah practiced","یو آیت ثبت کړئ","ثبت یک آیه تمرین‌شده","تسجيل آية تمت مراجعتها")){prefs.edit().putInt("memorized/$date",count+1).apply();render()};action(progress,t4("Undo","بېرته","لغو","تراجع")){prefs.edit().putInt("memorized/$date",(count-1).coerceAtLeast(0)).apply();render()};action(progress,l("Quran","قرآن")){go("quran")}
}
fun MainActivity.verseSearchScreen(){
    begin("AL NOOR",t4("Search verses","آیتونه ولټوئ","جستجوی آیات","البحث في الآيات"),editionCredit());val c=card();val input=EditText(this).apply{setTextColor(ink);setHintTextColor(muted);hint=t4("Search Arabic or meaning","عربي یا ژباړه","عربی یا ترجمه","العربية أو الترجمة")};c.addView(input);val out=LinearLayout(this).apply{orientation=1};body.addView(out);action(c,l("Search","لټون")){out.removeAllViews();val q=input.text.toString().trim();if(q.length<2)return@action;var count=0;outer@for(s in catalog.surahs)for((i,v)in s.verses.withIndex()){if(v.arabic.contains(q,true)||meaning(v).contains(q,true)){action(out,"${s.id}:${i+1} · ${titleOf(s)}"){openTranslation(s.id,i+1)};count++;if(count==100)break@outer}};if(count==0)out.addView(label(t4("No matches","پایله نشته","نتیجه‌ای یافت نشد","لا نتائج"),16))}
}
fun MainActivity.companionTiles(){
    entry(t4("Ambient clock","د سپوږمۍ ساعت","ساعت مهتابی","ساعة القمر"),t4("Moon and prayer countdown","سپوږمۍ او د لمانځه وخت","ماه و شمارش معکوس نماز","القمر والعد التنازلي للصلاة")){go("ambient")}
    entry(t4("Ramadan studio","د رمضان برخه","بخش رمضان","ركن رمضان"),t4("Suhoor and iftar planner","پېشلمی او روژه ماتی","سحری و افطار","السحور والإفطار")){go("ramadan")}
    entry(t4("Quran search","د قرآن لټون","جستجوی قرآن","البحث في القرآن"),t4("Find verses and meanings","آیتونه او ژباړې","آیات و ترجمه","الآيات والترجمات")){go("verseSearch")}
    entry(t4("Memorization & goals","حفظ او موخې","حفظ و اهداف","الحفظ والأهداف"),t4("Daily reading targets","ورځنۍ موخې","اهداف روزانه","الأهداف اليومية")){go("memorize")}
    entry(t4("Private journal","شخصي یادښت","یادداشت شخصی","مذكرات خاصة"),t4("Stored locally","په موبایل کې","ذخیره محلی","حفظ محلي")){go("journal")}
}

internal fun tintInputs(v: View) {
    if(v is EditText) {v.setTextColor(ink);v.setHintTextColor(muted)}
    if(v is Switch || v is CheckBox) (v as TextView).setTextColor(ink)
    if(v is ViewGroup) for(i in 0 until v.childCount) tintInputs(v.getChildAt(i))
}
