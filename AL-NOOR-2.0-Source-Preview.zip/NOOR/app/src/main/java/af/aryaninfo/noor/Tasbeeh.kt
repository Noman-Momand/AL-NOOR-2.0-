package af.aryaninfo.noor

import android.animation.ValueAnimator
import android.app.AlertDialog
import android.content.*
import android.graphics.*
import android.net.Uri
import android.view.*
import android.widget.*
import java.util.concurrent.Executors
import kotlin.math.*
import org.json.JSONObject

internal val counterIO = Executors.newSingleThreadExecutor()
private val phrases = listOf("سُبْحَانَ اللَّهِ", "الْحَمْدُ لِلَّهِ", "اللَّهُ أَكْبَرُ")

fun MainActivity.askCounterFile(restore: Boolean) {
    val i =
        Intent(if (restore) Intent.ACTION_OPEN_DOCUMENT else Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/plain"
            if (!restore) putExtra(Intent.EXTRA_TITLE, "Al-Noor-Tasbeeh.txt")
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }
    startActivityForResult(i, if (restore) 814 else 813)
}

private fun Context.snapshot(): String {
    val p = getSharedPreferences("noor", 0)
    return JSONObject()
        .apply {
            put("format", "al-noor-tasbeeh-1")
            for (i in phrases.indices) put("n$i", p.getLong("tas/$i", 0))
        }
        .toString()
}

private fun Context.saveCounter(uri: Uri, line: String, append: Boolean) {
    contentResolver.openOutputStream(uri, if (append) "wa" else "wt")!!.bufferedWriter().use {
        it.write("\n$line\n")
    }
}

internal fun counterValues(line: String): List<Long>? =
    runCatching {
            val j = JSONObject(line)
            require(j.getString("format") == "al-noor-tasbeeh-1")
            phrases.indices.map { j.getLong("n$it").also { v -> require(v in 0..1000000000000L) } }
        }
        .getOrNull()

fun MainActivity.counterFile(result: Int, data: Intent) {
    val uri = data.data ?: return
    try {
        contentResolver.takePersistableUriPermission(
            uri,
            data.flags and
                (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION),
        )
    } catch (e: SecurityException) {
        Toast.makeText(
                this,
                l("Choose a writable document", "د لیکلو وړ فایل وټاکئ"),
                Toast.LENGTH_LONG,
            )
            .show()
        return
    }
    val line = snapshot()
    counterIO.execute {
        val values = runCatching {
            if (result == 814)
                contentResolver.openInputStream(uri)!!.bufferedReader().useLines { lines ->
                    lines.mapNotNull(::counterValues).lastOrNull() ?: error("format")
                }
            else {
                saveCounter(uri, line, false)
                null
            }
        }
        runOnUiThread {
            values
                .onSuccess { restored ->
                    val edit = prefs.edit().putString("tasFile", uri.toString())
                    restored?.forEachIndexed { i, v -> edit.putLong("tas/$i", v) }
                    edit.apply()
                    if (!isDestroyed && !isFinishing) render()
                }
                .onFailure {
                    Toast.makeText(
                            this,
                            l("Could not use this backup", "د دې شاتړ فایل کارول ممکن نه شول"),
                            Toast.LENGTH_LONG,
                        )
                        .show()
                }
        }
    }
}

private class BeadView(
    c: Context,
    var beads: Boolean,
    var count: Long,
    var goal: Int,
    val advance: () -> Unit,
) : View(c) {
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    var motion = 0f
    var start = 0f

    init {
        isClickable = true
        isFocusable = true
    }

    override fun performClick(): Boolean {
        super.performClick()
        advance()
        return true
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                start = e.x
                parent.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!beads || abs(e.x - start) > width * .09f) performClick()
                parent.requestDisallowInterceptTouchEvent(false)
                return true
            }
            MotionEvent.ACTION_CANCEL -> parent.requestDisallowInterceptTouchEvent(false)
        }
        return true
    }

    fun pulse() {
        ValueAnimator.ofFloat(1f, 0f).apply {
            duration = 210
            addUpdateListener {
                motion = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val x = w / 2
        val y = h * .42f
        val r = min(w * .26f, h * .31f)
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * .10f
        p.color = 0xffc8d7cb.toInt()
        c.drawCircle(x, y, r, p)
        p.color = ink
        p.strokeCap = Paint.Cap.ROUND
        c.drawArc(x - r, y - r, x + r, y + r, -90f, 360f * (count % goal) / goal, false, p)
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.SERIF
        p.textSize = r * (.72f + .06f * motion)
        p.color = ink
        c.drawText(count.toString(), x, y + r * .20f, p)
        p.textSize = r * .2f
        c.drawText("/ $goal", x, y + r * .55f, p)
        if (beads) {
            val cy = h * .85f
            p.color = 0xff997f58.toInt()
            p.strokeWidth = 3f
            c.drawLine(0f, cy, w, cy, p)
            val rad = w * .073f
            for (i in -1..7) {
                val cx = (i + .45f + motion * .40f) * w / 6
                p.shader =
                    RadialGradient(
                        cx - rad * .34f,
                        cy - rad * .38f,
                        rad * 1.55f,
                        intArrayOf(0xffdcefd5.toInt(), 0xff4e9079.toInt(), 0xff143e34.toInt()),
                        null,
                        Shader.TileMode.CLAMP,
                    )
                c.drawCircle(cx, cy, rad, p)
            }
            p.shader = null
        }
    }
}

fun MainActivity.tasbeeh() {
    val index = prefs.getInt("tasPhrase", 0).coerceIn(0, 2)
    val goal = prefs.getInt("tasGoal", 33).coerceIn(1, 9999)
    val beads = prefs.getBoolean("beads", false)
    begin(
        l("Remembrance", "ذکر"),
        l("Digital Tasbeeh", "برېښنايي تسبېح"),
        l("Tap a counter or slide a bead", "تڼۍ کېکاږئ یا یوه دانه وښويوئ"),
    )
    val c = card()
    rtl(c, phrases[index], 30)
    c.addView(
        label(
            listOf(
                l("Glory be to Allah", "الله پاک دی"),
                l("All praise belongs to Allah", "ټولې ستاینې الله لره دي"),
                l("Allah is the Greatest", "الله تر ټولو لوی دی"),
            )[index],
            18,
        )
    )
    val key = "tas/$index"
    lateinit var dial: BeadView
    fun setCount(v: Long) {
        prefs.edit().putLong(key, v).apply()
        dial.count = v
        dial.contentDescription = l("Count $v", "شمېر $v")
        dial.pulse()
        val file = prefs.getString("tasFile", null) ?: return
        val data = snapshot()
        counterIO.execute {
            runCatching { saveCounter(Uri.parse(file), data, true) }
                .onFailure {
                    runOnUiThread {
                        if (!isDestroyed)
                            Toast.makeText(
                                    this,
                                    l(
                                        "Local count saved. Reconnect the backup file.",
                                        "شمېر خوندي شو. د شاتړ فایل بیا وتړئ.",
                                    ),
                                    Toast.LENGTH_LONG,
                                )
                                .show()
                    }
                }
        }
    }
    dial =
        BeadView(this, beads, prefs.getLong(key, 0), goal) {
            setCount((prefs.getLong(key, 0) + 1).coerceAtMost(1000000000000L))
        }
    dial.background = bg(0xffeef1e7.toInt(), dp(20).toFloat())
    dial.contentDescription = l("Tasbeeh count", "د تسبېح شمېر")
    c.addView(dial, LinearLayout.LayoutParams(-1, dp(245)))
    if (!beads) action(c, l("Tap to count", "د شمېر لپاره کېکاږئ")) { dial.performClick() }
    action(
        c,
        if (beads) l("Switch to button", "تڼۍ وکاروئ")
        else l("Switch to swipe beads", "د تسبېح دانې وکاروئ"),
    ) {
        prefs.edit().putBoolean("beads", !beads).apply()
        render()
    }
    action(c, l("Choose dhikr", "ذکر وټاکئ")) {
        AlertDialog.Builder(this)
            .setItems(phrases.toTypedArray()) { _, i ->
                prefs.edit().putInt("tasPhrase", i).apply()
                render()
            }
            .show()
    }
    action(c, l("Personal target · $goal", "شخصي موخه · $goal")) {
        AlertDialog.Builder(this)
            .setItems(arrayOf("33", "99", "100")) { _, i ->
                prefs.edit().putInt("tasGoal", listOf(33, 99, 100)[i]).apply()
                render()
            }
            .show()
    }
    action(c, l("Reset this count", "دا شمېر له سره پیل کړئ")) {
        AlertDialog.Builder(this)
            .setMessage(l("Reset this dhikr to zero?", "د دې ذکر شمېر صفر شي؟"))
            .setPositiveButton(android.R.string.ok) { _, _ -> setCount(0) }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
    val backup = card()
    backup.addView(
        label(
            if (prefs.contains("tasFile")) l("Portable save connected", "شاتړ فایل تړلی دی")
            else l("Keep counts after uninstall", "تر ړنګولو وروسته د شمېرو ساتل"),
            20,
        )
    )
    backup.addView(
        label(
            l(
                "Choose a file in Documents once. New counts are written there. After reinstalling, restore that file.",
                "یو ځل په اسنادو کې فایل وټاکئ. نوي شمېرونه پکې ساتل کېږي. له بیا نصب وروسته هماغه فایل بېرته پرانیزئ.",
            ),
            15,
        )
    )
    action(backup, l("Choose backup file", "د شاتړ فایل جوړول")) { askCounterFile(false) }
    action(backup, l("Restore from file", "له فایل څخه راګرځول")) { askCounterFile(true) }
}
