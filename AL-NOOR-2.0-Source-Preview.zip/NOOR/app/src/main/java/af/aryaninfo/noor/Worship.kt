package af.aryaninfo.noor

import android.app.AlertDialog
import android.graphics.BitmapFactory
import android.widget.*

private fun MainActivity.photo(
    panel: LinearLayout,
    file: String,
    description: String,
    height: Int,
) {
    val pic = ImageView(this)
    pic.setImageBitmap(assets.open(file).use { BitmapFactory.decodeStream(it) })
    pic.contentDescription = description
    pic.scaleType = ImageView.ScaleType.FIT_CENTER
    pic.background = bg(0xfff2ede1.toInt(), dp(12).toFloat())
    pic.clipToOutline = true
    panel.addView(pic, LinearLayout.LayoutParams(-1, dp(height)))
}

private fun MainActivity.openChapter(id: Int) {
    chapter = id
    go("chapter")
}

fun MainActivity.occasions() {
    begin(
        l("Remembrance", "دعاګانې"),
        l("Daily supplications", "ورځنۍ دعاګانې"),
        l("Find an invocation for this moment", "د خپل وخت او حالت دعا ومومئ"),
    )
    fun group(title: String, detail: String, ids: List<Int>) {
        entry(title, detail) {
            val chapters = ids.map { id -> catalog.chapters.first { it.id == id } }
            AlertDialog.Builder(this)
                .setTitle(title)
                .setItems(chapters.map { chapterName(it) }.toTypedArray()) { _, i ->
                    openChapter(chapters[i].id)
                }
                .show()
        }
    }
    group(
        l("Morning", "سهار"),
        l("Waking and morning remembrance", "له خوبه پاڅېدل او د سهار اذکار"),
        listOf(1, 27),
    )
    group(
        l("Afternoon", "ماسپښین"),
        l(
            "After Dhuhr or Asr and general remembrance",
            "د ماسپښین او مازدیګر له لمانځه وروسته او عمومي اذکار",
        ),
        listOf(25, 129, 130, 131),
    )
    group(
        l("Evening & bedtime", "ماښام او د خوب وخت"),
        l("Evening remembrance and sleep", "د ماښام او خوب اذکار"),
        listOf(27, 28, 29, 30, 31),
    )
    group(
        l("Clothing", "جامې"),
        l("Getting dressed, new clothes and undressing", "د جامو اغوستل، نوې جامې او ایستل"),
        (2..5).toList(),
    )
    group(
        l("Home, mosque & purification", "کور، جومات او پاکوالی"),
        l("Entering, leaving, wudu and the call to prayer", "ننوتل، وتل، اودس او اذان"),
        (6..15).toList(),
    )
    group(
        l("Food & fasting", "خواړه او روژه"),
        l("Meals, guests and breaking the fast", "خواړه، مېلمانه او روژه ماتول"),
        (68..76).toList(),
    )
    group(
        l("Travel", "سفر"),
        l("Departure, journeys and returning home", "روانېدل، سفر او راستنېدل"),
        (95..105).toList(),
    )
    group(
        l("Difficulty & illness", "سختي او ناروغي"),
        l(
            "Worry, difficulty, illness and seeking relief",
            "اندېښنه، ستونزې، ناروغي او د اسانتیا غوښتنه",
        ),
        listOf(34, 35, 43, 49, 53, 124),
    )
    entry(
        l("All supplications", "ټولې دعاګانې"),
        l("Browse all 132 chapters of Hisn al-Muslim", "د حصن المسلم ټول ۱۳۲ څپرکي وګورئ"),
    ) {
        go("adhkar")
    }
}

fun MainActivity.wuduGuide() {
    begin(
        l("Purification", "پاکوالی"),
        l("How to make Wudu", "د اوداسه طریقه"),
        l("Hanafi practice   ·   Illustrated sequence", "د حنفي فقهې انځوریز لارښود"),
    )
    val details =
        listOf(
            Triple(
                "hands",
                l("Begin and wash the hands", "نیت او د لاسونو مینځل"),
                l(
                    "Intend purification in your heart, say Bismillah and wash both hands to the wrists. Start with the right.",
                    "په زړه کې د پاکوالي نیت وکړئ، بسم الله ووایئ او دواړه لاسونه تر مړوندونو ومینځئ. له ښي لاسه پیل وکړئ.",
                ),
            ),
            Triple(
                "rinse",
                l("Rinse the mouth and nose", "خوله او پوزه مینځل"),
                l(
                    "Rinse the mouth and gently draw water into the nose, then clear it. Repeat three times. Avoid drawing water deeply when fasting.",
                    "خوله ومینځئ، په نرمۍ پوزې ته اوبه واچوئ او بېرته یې وباسئ. درې ځله یې تکرار کړئ. روژه کې اوبه ډېرې پورته مه کشوئ.",
                ),
            ),
            Triple(
                "face",
                l("Wash the whole face", "ټول مخ ومینځئ"),
                l(
                    "Wash from the usual hairline to the chin and across the full width of the face. Water should reach the whole area.",
                    "مخ د وېښتانو له عادي ځایه تر زنې او له یوه اړخه تر بل اړخه ومینځئ. اوبه باید ټول مخ ته ورسېږي.",
                ),
            ),
            Triple(
                "arms",
                l("Wash the arms", "د دواړو مټو مینځل"),
                l(
                    "Start with the right arm, then the left. Wash from the fingertips up to and including each elbow.",
                    "لومړی ښی او بیا کیڼ لاس د ګوتو له څوکو تر څنګلو پورې ومینځئ. څنګلې هم ومینځئ.",
                ),
            ),
            Triple(
                "head",
                l("Wipe the head and ears", "د سر او غوږونو مسح"),
                l(
                    "Pass wet hands over the head once, then wipe the ears. Wiping at least one quarter of the head fulfils the Hanafi minimum for the head.",
                    "یو ځل لمده لاسونه پر سر تېر کړئ، بیا غوږونه مسح کړئ. په حنفي فقه کې لږ تر لږه د سر څلورمه برخه مسح کول فرض دي.",
                ),
            ),
            Triple(
                "feet",
                l("Wash both feet", "دواړه پښې ومینځئ"),
                l(
                    "Start on the right. Wash each foot up to and including the ankle bones. Reach the heels and between the toes.",
                    "له ښۍ پښې پیل وکړئ. دواړه پښې د ښنګرو په ګډون ومینځئ. پوندو او د ګوتو منځ ته اوبه ورسوئ.",
                ),
            ),
        )
    details.forEachIndexed { i, (image, title, body) ->
        val panel = card()
        photo(panel, "wudu-$image.webp", title, 185)
        panel.addView(label("${i+1}. $title", 22, ink, true))
        panel.addView(label(body, 17))
    }
    val note = card()
    note.addView(label(l("The four obligatory actions", "د اوداسه څلور فرضونه"), 20, ink, true))
    note.addView(
        label(
            l(
                "Wash the face, both arms including the elbows, and both feet including the ankles. Wipe at least one quarter of the head. In ordinary wudu, washing three times is Sunnah and one complete wash fulfils the washing requirement.",
                "مخ، دواړه لاسونه له څنګلو سره او دواړه پښې له ښنګرو سره ومینځئ. لږ تر لږه د سر څلورمه برخه مسح کړئ. په عادي اوداسه کې یو بشپړ مینځل فرض ادا کوي او درې ځله مینځل سنت دي.",
            ),
            16,
        )
    )
    note.addView(
        label(
            l(
                "Quran 5:6 · Maraqi al-Falah, purification. Illustrations are AI-generated teaching aids.",
                "قرآن ۵:۶ · مراقي الفلاح، د طهارت باب. انځورونه د زده کړې لپاره په مصنوعي ځیرکتیا جوړ شوي.",
            ),
            13,
            muted,
        )
    )
    action(note, l("Supplication after Wudu", "تر اوداسه وروسته دعا")) { openChapter(9) }
}

fun MainActivity.salahGuide() {
    begin(
        l("Worship", "عبادت"),
        l("Learn to pray", "د لمانځه زده کړه"),
        l("Hanafi Salah   ·   Individual daily prayer", "حنفي طریقه · یوازې لمونځ کوونکی"),
    )
    val intro = card()
    intro.addView(label(l("Choose a prayer", "لمونځ وټاکئ"), 23, ink, true))
    val names =
        listOf(
            l("Fajr", "سهار"),
            l("Dhuhr", "ماسپښین"),
            l("Asr", "مازدیګر"),
            l("Maghrib", "ماښام"),
            l("Isha", "ماسخوتن"),
            l("Witr", "وتر"),
        )
    val counts = listOf(2, 4, 4, 3, 4, 3)
    val which = prefs.getInt("guidePrayer", 0).coerceIn(0, 5)
    val units = counts[which]
    action(intro, names[which] + "   ·   " + units + l(" rakʿahs", " رکعته")) {
        AlertDialog.Builder(this)
            .setTitle(l("Prayer", "لمونځ"))
            .setItems(names.toTypedArray()) { _, n ->
                prefs.edit().putInt("guidePrayer", n).apply()
                render()
            }
            .show()
    }
    fun step(title: String, body: String): LinearLayout =
        card().also {
            it.addView(label(title, 22, ink, true))
            it.addView(label(body, 17))
        }
    fun words(panel: LinearLayout, id: Int, item: Int) {
        val e = catalog.chapters.first { it.id == id }.entries.first { it.id == item }
        rtl(panel, e.text, 25)
        panel.addView(
            label(l("Hisn al-Muslim · $id / $item", "حصن المسلم · $id / $item"), 12, muted)
        )
    }
    val start =
        step(
            l("Prepare", "چمتووالی"),
            l(
                "Check the prayer time, complete the required purification, cover the required parts of the body and choose a clean place. Face the Qibla and intend the prayer you are about to perform.",
                "د لمانځه وخت وګورئ، لازم طهارت وکړئ، عورت پټ کړئ او پاک ځای غوره کړئ. قبلې ته مخ کړئ او د لمانځه نیت وکړئ.",
            ),
        )
    action(start, l("Wudu guide", "د اوداسه لارښود")) { go("wudu") }
    action(start, l("Prayer times & Qibla", "د لمانځه وختونه او قبله")) { go("prayer") }
    val standing =
        step(
            l("First rakʿah · stand and begin", "لومړی رکعت · قیام او پیل"),
            l(
                "Stand if able. Raise your hands and say Allahu akbar, then fold your hands. Recite the opening praise, seek refuge in Allah and say the basmalah.",
                "که توان لرئ ودرېږئ. لاسونه پورته کړئ او الله اکبر ووایئ، بیا لاسونه وتړئ. ثنا، اعوذ بالله او بسم الله ولولئ.",
            ),
        )
    rtl(standing, "اللَّهُ أَكْبَرُ", 25)
    words(standing, 16, 28)
    rtl(standing, "أَعُوذُ بِاللَّهِ مِنَ الشَّيْطَانِ الرَّجِيمِ", 25)
    val rec =
        step(
            l("Recite", "قرائت"),
            l(
                "Recite al-Fatihah, say Amin, then recite another surah or passage. Here are al-Fatihah and al-Ikhlas as a practice example.",
                "فاتحه ولولئ، آمین ووایئ او بیا بل سورت یا څو آیتونه ولولئ. دلته فاتحه او اخلاص د بېلګې په توګه راوړل شوي.",
            ),
        )
    for (id in listOf(1, 112)) rtl(
        rec,
        catalog.surahs[id - 1]
            .verses
            .mapIndexed { index, v -> opening(Ref(id, index + 1), v.arabic) }
            .joinToString("  "),
        25,
    )
    val bow =
        step(
            l("Bow · rukuʿ", "رکوع"),
            l(
                "Say Allahu akbar and bow. Rest your hands on your knees and settle in the posture. Glorify Allah.",
                "الله اکبر ووایئ او رکوع ته لاړ شئ. لاسونه پر زنګنو کېږدئ، په ارام ودرېږئ او تسبیح ووایئ.",
            ),
        )
    words(bow, 17, 33)
    val rise =
        step(
            l("Stand upright", "له رکوع پورته کېدل"),
            l(
                "Rise fully. When praying alone, say the words of rising, then praise Allah.",
                "نېغ ودرېږئ. که یوازې لمونځ کوئ، د رکوع څخه د پورته کېدو ذکر او بیا د الله حمد ووایئ.",
            ),
        )
    words(rise, 18, 38)
    rtl(rise, "رَبَّنَا لَكَ الْحَمْدُ", 25)
    val pro =
        step(
            l("Two prostrations · sujud", "دوه سجدې"),
            l(
                "Say Allahu akbar and prostrate. Place forehead and nose, palms, knees and toes on the ground as able. Glorify Allah. Rise with the takbir, sit upright, then make the second prostration with the takbir.",
                "الله اکبر ووایئ او سجده وکړئ. د وس په اندازه تندی، پوزه، ورغوي، زنګنونه او د پښو ګوتې پر ځمکه کېږدئ. تسبیح ووایئ. په تکبیر راپاڅئ، کېنئ او بیا په تکبیر دویمه سجده وکړئ.",
            ),
        )
    words(pro, 19, 41)
    val sitting =
        step(
            l("Second rakʿah and sitting", "دویم رکعت او قعده"),
            l(
                "Rise for the second unit. Begin with the basmalah, recite al-Fatihah and another passage, then repeat the bow, standing and two prostrations. Sit and recite the tashahhud.",
                "دویم رکعت ته پورته شئ. بسم الله، فاتحه او بل سورت یا آیتونه ولولئ. رکوع، قومه او دواړه سجدې وکړئ. په قعده کې تشهد ولولئ.",
            ),
        )
    words(sitting, 22, 52)
    if (units > 2) {
        val later =
            step(
                if (units == 3) l("Third rakʿah", "درېیم رکعت")
                else l("Third and fourth rakʿahs", "درېیم او څلورم رکعتونه"),
                if (which == 5)
                    l(
                        "Stand for the third unit of Witr. Recite al-Fatihah and another passage. Raise the hands with an additional takbir, fold them, and recite qunut before bowing. Complete the bow and prostrations and sit for tashahhud.",
                        "د وترو درېیم رکعت ته ودرېږئ. فاتحه او بل سورت ولولئ. د اضافي تکبیر سره لاسونه پورته او بیا وتړئ. له رکوع مخکې قنوت ولولئ. رکوع او سجدې بشپړې کړئ او تشهد ته کېنئ.",
                    )
                else
                    l(
                        "After the first sitting, stand and recite al-Fatihah. Complete the bow, standing and both prostrations in each remaining unit. After the last unit sit and recite tashahhud again.",
                        "تر لومړۍ قعدې وروسته ودرېږئ او فاتحه ولولئ. په پاتې رکعتونو کې رکوع، قومه او سجدې وکړئ. په پای کې کېنئ او بیا تشهد ولولئ.",
                    ),
            )
        if (which == 5)
            action(later, l("Read Qunut supplications", "د قنوت دعاګانې ولولئ")) { openChapter(32) }
    }
    val end =
        step(
            l("Final sitting and salam", "وروستۍ قعده او سلام"),
            l(
                "After tashahhud, recite blessings on the Prophet ﷺ, then a supplication. Turn to the right and then to the left, saying the salam on each side.",
                "تر تشهد وروسته پر نبي ﷺ درود او بیا دعا ولولئ. لومړی ښي او بیا کیڼ لوري ته مخ واړوئ او دواړو خواوو ته سلام ووایئ.",
            ),
        )
    words(end, 23, 53)
    words(end, 24, 57)
    rtl(end, "السَّلَامُ عَلَيْكُمْ وَرَحْمَةُ اللَّهِ", 25)
    action(end, l("Remembrance after prayer", "تر لمانځه وروسته اذکار")) { openChapter(25) }
    end.addView(
        label(
            l(
                "Hanafi sequence · Nur al-Idah, Book of Prayer. Recitation examples come from the bundled Quran and Hisn al-Muslim.",
                "حنفي طریقه · نور الایضاح، د لمانځه کتاب. د قرائت او دعا بېلګې له قرآن او حصن المسلم څخه دي.",
            ),
            13,
            muted,
        )
    )
}

fun MainActivity.founder() {
    begin(
        l("Developer", "پېژندنه"),
        l("About the developer", "د جوړوونکي پېژندنه"),
        l("Aryan Info-Tech   ·   Kabul, Afghanistan", "آریان انفوتېک · کابل، افغانستان"),
    )
    val author = card()
    photo(
        author,
        "noman-momand.jpg",
        l("Noman Momand, founder of Aryan Info-Tech", "نعمان مومند، د آریان انفوتېک بنسټګر"),
        265,
    )
    author.addView(label(l("Noman Momand", "نعمان مومند"), 28, ink, true))
    author.addView(
        label(
            l("Founder & CEO, Aryan Info-Tech", "د آریان انفوتېک بنسټګر او اجرائیوي مشر"),
            16,
            muted,
        )
    )
    fun story(title: String, body: String) {
        val p = card()
        p.addView(label(title, 23, ink, true))
        p.addView(label(body, 17))
    }
    story(
        l("Why I built NOOR", "ولې مې النور جوړ کړ؟"),
        l(
            "I wanted a Pashto-speaking reader to be able to open the Quran, find a familiar page, and read its meaning, even when there is no internet. I hope NOOR helps someone return to an ayah they love, learn the words of prayer, or remember Allah in the middle of an ordinary day.",
            "غوښتل مې چې پښتو لوستونکی قرآن پرانیزي، خپله اشنا پاڼه ومومي او ان له انټرنېټ پرته یې په معنا پوه شي. هیله لرم النور له چا سره مرسته وکړي چې خپل د خوښې آیت بیا ولولي، د لمانځه الفاظ زده کړي یا د ورځې په منځ کې الله یاد کړي.",
        ),
    )
    story(
        l("What teaching taught me", "له ښوونې مې څه زده کړل؟"),
        l(
            "I began teaching English at the Muslim English Language Institute in 2023. Teaching taught me to notice the moment a learner gets stuck. A clear instruction, a familiar word or a page that is easier to read can make all the difference. That lesson shaped the way I approached NOOR.",
            "په ۲۰۲۳ کال کې مې د مسلم د انګلیسي ژبې په انستیتوت کې تدریس پیل کړ. ښوونې را وښودله چې زده کوونکی چېرته مرستې ته اړتیا لري. یوه روښانه لارښوونه، اشنا کلمه یا لوستلو ته اسانه پاڼه لوی توپیر کوي. النور مې هم په همدې فکر جوړ کړ.",
        ),
    )
    story(
        l("Building from Kabul", "په کابل کې پیل"),
        l(
            "I founded Aryan Info-Tech in 2024 while studying computing at Kardan University. Receiving the Academic Excellence Award in Spring 2025 encouraged me to keep learning. My work in networking, cybersecurity and education keeps bringing me back to one question. Who can use what I have learned?",
            "په ۲۰۲۴ کال کې مې د کاردان پوهنتون د کمپیوټر د زده کړو پر مهال آریان انفوتېک جوړ کړ. د ۲۰۲۵ کال په پسرلي کې د علمي غوره والي جایزې لا هڅولی یم چې زده کړه ته دوام ورکړم. په شبکه، سایبري امنیت او تدریس کې تل له ځانه پوښتم: زما زده کړه چاته ګټه رسولی شي؟",
        ),
    )
    story(
        l("My intention", "زما نیت"),
        l(
            "I offer this work with the hope that it brings benefit. I am its developer. The Quran text, Pashto translation and supplications come from the sources credited in the app. May Allah accept what is good in it and guide us to correct its shortcomings.",
            "هیله لرم دا کار ګټور وي. زه د اپ جوړوونکی یم. د قرآن متن، ژباړې او دعاګانې له هغو سرچینو اخیستل شوې چې په اپ کې ښودل شوې دي. الله دې ښه کارونه قبول او د نیمګړتیاوو سمولو ته دې مو هدایت کړي.",
        ),
    )
    action(card(), l("Content sources and editions", "د متنونو سرچینې او چاپونه")) { go("legal") }
}
