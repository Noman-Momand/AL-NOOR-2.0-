package af.aryaninfo.noor

import android.app.AlertDialog
import android.graphics.*
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.widget.*
import java.io.File

fun MainActivity.bookChapter(id: Int) {
    val lang = if (ps) "ps" else "en"
    val page =
        assets.open("hisn-pages-$lang.txt").bufferedReader().use { it.readLines()[id - 1].toInt() }
    prefs.edit().putInt("bookpage/$lang", page).apply()
    go("book")
}

fun MainActivity.fullBook() {
    // Only these two published PDF editions are bundled; do not relabel them.
    val lang = if (ps) "ps" else "en"
    val key = "bookpage/$lang"
    val path = File(cacheDir, "hisn-v3-$lang.pdf")
    if (!path.exists()) {
        val tmp = File.createTempFile("hisn", ".tmp", cacheDir)
        try {
            assets.open("hisn-$lang.pdf").use { src -> tmp.outputStream().use { src.copyTo(it) } }
            check(tmp.renameTo(path))
        } finally {
            tmp.delete()
        }
    }
    begin(
        l("Library", "کتابتون"),
        l("Hisn al-Muslim", "حصن المسلم"),
        l("Complete English edition · IslamHouse", "بشپړ پښتو چاپ · اسلام هاوس"),
    )
    if (language in listOf("prs", "ar")) {
        val notice=card()
        notice.addView(label(t4("English edition below", "انګلیسي چاپ", "نسخه انگلیسی در پایین؛ نسخه دری هنوز افزوده نشده است.", "النسخة الإنجليزية أدناه؛ النص العربي في أبواب الأذكار."),16))
        action(notice,t4("Arabic supplications","عربي دعاګانې","دعاهای عربی","الأدعية العربية")){go("adhkar")}
    }
    PdfRenderer(ParcelFileDescriptor.open(path, ParcelFileDescriptor.MODE_READ_ONLY)).use { pdf ->
        val n = prefs.getInt(key, 1).coerceIn(1, pdf.pageCount)
        val count = pdf.pageCount
        fun open(i: Int) {
            prefs.edit().putInt(key, i.coerceIn(1, count)).apply()
            render()
        }
        val tools = LinearLayout(this)
        body.addView(tools)
        action(tools, l("Previous", "مخکینۍ")) { open(n - 1) }
        action(tools, "$n / $count") {
            val input =
                EditText(this).apply {
                    inputType = 2
                    hint = "1–$count"
                }
            AlertDialog.Builder(this)
                .setTitle(l("Go to book page", "د کتاب پاڼه وټاکئ"))
                .setView(input)
                .setPositiveButton(android.R.string.ok) { _, _ ->
                    input.text.toString().toIntOrNull()?.let { open(it) }
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }
        action(tools, l("Next", "بله")) { open(n + 1) }
        pdf.openPage(n - 1).use { page ->
            val w = resources.displayMetrics.widthPixels.coerceIn(720, 1300)
            val image =
                Bitmap.createBitmap(w, w * page.height / page.width, Bitmap.Config.ARGB_8888)
            image.eraseColor(Color.WHITE)
            page.render(image, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            body.addView(
                ImageView(this).apply {
                    setImageBitmap(image)
                    adjustViewBounds = true
                    contentDescription = l("Book page $n", "د کتاب $n پاڼه")
                },
                LinearLayout.LayoutParams(-1, -2),
            )
        }
    }
}
