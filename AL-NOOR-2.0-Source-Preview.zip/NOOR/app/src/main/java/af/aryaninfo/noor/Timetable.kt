package af.aryaninfo.noor

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri
import android.widget.*
import com.batoulapps.adhan.CalculationMethod
import java.net.URL
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import javax.net.ssl.HttpsURLConnection
import org.json.JSONObject

internal val prayerNames = listOf("Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha")

internal class Timetables(context: Context) :
    SQLiteOpenHelper(context, "prayer-timetables.db", null, 1), java.io.Closeable {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE timetable (lookup TEXT PRIMARY KEY, day TEXT NOT NULL, times TEXT NOT NULL)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, old: Int, new: Int) {}

    fun read(k: String): JSONObject? =
        readableDatabase.rawQuery("SELECT times FROM timetable WHERE lookup=?", arrayOf(k)).use {
            if (it.moveToFirst()) JSONObject(it.getString(0)) else null
        }

    fun store(k: String, date: LocalDate, times: JSONObject) {
        val row =
            ContentValues().apply {
                put("lookup", k)
                put("day", date.toString())
                put("times", times.toString())
            }
        writableDatabase.replaceOrThrow("timetable", null, row)
        writableDatabase.delete("timetable", "day < ?", arrayOf(date.minusDays(45).toString()))
    }
}

internal fun timetableResponse(body: String, date: String, zone: String, method: Int): JSONObject {
    val response = JSONObject(body)
    check(response.getInt("code") == 200)
    val data = response.getJSONObject("data")
    val meta = data.getJSONObject("meta")
    check(data.getJSONObject("date").getJSONObject("gregorian").getString("date") == date)
    check(
        meta.getString("timezone") == zone &&
            meta.getString("school").equals("HANAFI", true) &&
            meta.getJSONObject("method").getInt("id") == method
    )
    val timings = data.getJSONObject("timings")
    return JSONObject().apply {
        prayerNames.forEach { name ->
            put(
                name,
                LocalTime.parse(timings.getString(name))
                    .format(DateTimeFormatter.ofPattern("HH:mm")),
            )
        }
    }
}

fun MainActivity.onlineTimetable(
    panel: LinearLayout,
    place: Place,
    date: LocalDate,
    method: CalculationMethod,
): JSONObject? {
    val id =
        when (method) {
            CalculationMethod.KARACHI -> 1
            CalculationMethod.UMM_AL_QURA -> 4
            else -> 3
        }
    val k = listOf(date, place.lat, place.lon, place.zone.id, id, "hanafi").joinToString("|")
    val cache = Timetables(this).use { it.read(k) }
    val use = prefs.getBoolean("onlinePrayer", false)
    panel.addView(
        label(
            if (use && cache != null)
                l(
                    "Source · AlAdhan, saved on this device",
                    "سرچینه · په موبایل کې خوندي شوي د الاذان وختونه",
                )
            else l("Source · Offline calculation", "سرچینه · بې انټرنېټه حساب"),
            15,
            muted,
        )
    )
    panel.addView(
        label(
            l(
                "An online refresh sends the selected coordinates, date and time zone to AlAdhan.",
                "تازه کول ټاکلي مختصات، نېټه او وخت سیمه الاذان ته لېږي.",
            ),
            13,
            muted,
        )
    )
    val button =
        Button(this).apply {
            text = l("Refresh from AlAdhan", "له الاذان څخه تازه کول")
            isAllCaps = false
        }
    panel.addView(button)
    button.setOnClickListener {
        button.isEnabled = false
        button.text = l("Fetching timetable…", "وختونه ترلاسه کېږي…")
        Thread {
                val ok =
                    runCatching {
                            val day =
                                date.format(
                                    DateTimeFormatter.ofPattern("dd-MM-yyyy", java.util.Locale.ROOT)
                                )
                            val uri =
                                Uri.parse("https://api.aladhan.com/v1/timings/$day")
                                    .buildUpon()
                                    .appendQueryParameter("latitude", place.lat.toString())
                                    .appendQueryParameter("longitude", place.lon.toString())
                                    .appendQueryParameter("method", id.toString())
                                    .appendQueryParameter("school", "1")
                                    .appendQueryParameter("timezonestring", place.zone.id)
                                    .build()
                            val conn = URL(uri.toString()).openConnection() as HttpsURLConnection
                            try {
                                conn.connectTimeout = 9500
                                conn.readTimeout = 9500
                                check(conn.responseCode == 200)
                                val payload =
                                    conn.inputStream.bufferedReader().use { it.readText() }
                                Timetables(applicationContext).use {
                                    it.store(
                                        k,
                                        date,
                                        timetableResponse(payload, day, place.zone.id, id),
                                    )
                                }
                            } finally {
                                conn.disconnect()
                            }
                        }
                        .isSuccess
                runOnUiThread {
                    if (!isFinishing && !isDestroyed && button.isAttachedToWindow) {
                        if (ok) prefs.edit().putBoolean("onlinePrayer", true).apply()
                        else
                            Toast.makeText(
                                    this,
                                    l(
                                        "Refresh unavailable. Showing the available timetable.",
                                        "تازه کول بریالي نه شول. شته مهالوېش ښودل کېږي.",
                                    ),
                                    Toast.LENGTH_LONG,
                                )
                                .show()
                        render()
                    }
                }
            }
            .start()
    }
    if (cache != null)
        action(
            panel,
            if (use) l("Use offline calculation", "بې انټرنېټه حساب وکاروئ")
            else l("Use saved online timings", "خوندي شوي آنلاین وختونه وکاروئ"),
        ) {
            prefs.edit().putBoolean("onlinePrayer", !use).apply()
            render()
        }
    return if (use) cache else null
}
