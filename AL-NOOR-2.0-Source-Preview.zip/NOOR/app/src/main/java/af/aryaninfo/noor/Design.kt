package af.aryaninfo.noor

import android.app.Activity
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.*
import kotlin.math.*

internal var ink = 0xff173e35.toInt()
internal var muted = 0xff52675e.toInt()
internal var paper = 0xfff7f4ea.toInt()
internal var gold = 0xffeacb89.toInt()
internal var surfaceColor = 0xfffffdf6.toInt()
internal var heroColor = 0xff173e35.toInt()
internal var controlColor = 0xffe0ebe0.toInt()
internal var darkPalette = false

fun Activity.dp(n: Int) = (resources.displayMetrics.density * n + 0.5f).toInt()

fun bg(color: Int, radius: Float = 0f) =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

class TileArt(context: android.content.Context) : View(context) {
    private val pen =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = 0x36f2d9a5
            strokeWidth = 1.6f
        }

    override fun onDraw(canvas: Canvas) {
        val span = minOf(width * .29f, height * .90f)
        val center = width * .91f
        for (i in 0..2) {
            val w = span * (1f - i * .12f)
            val arch =
                Path().apply {
                    moveTo(center - w, height.toFloat())
                    lineTo(center - w, height * .67f)
                    cubicTo(
                        center - w,
                        height * .37f,
                        center - w * .33f,
                        height * .29f,
                        center,
                        height * .08f + i * 3f,
                    )
                    cubicTo(
                        center + w * .33f,
                        height * .29f,
                        center + w,
                        height * .37f,
                        center + w,
                        height * .67f,
                    )
                    lineTo(center + w, height.toFloat())
                }
            canvas.drawPath(arch, pen)
        }
        val r = height / 4f
        for (row in -1..3) for (col in 0..2) {
            val cx = width - col * r * 1.49f
            val cy = row * r * 1.49f
            val path = Path()
            for (i in 0 until 16) {
                val angle = i * PI / 8
                val radius = if (i % 2 == 0) r else r * .55f
                val x = cx + (cos(angle) * radius).toFloat()
                val y = cy + (sin(angle) * radius).toFloat()
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            canvas.drawPath(path, pen)
        }
    }
}

open class Screen : Activity() {
    val readingTypeface by lazy { Typeface.createFromAsset(assets, "ScheherazadeNew-Regular.ttf") }
    lateinit var body: LinearLayout
    lateinit var scroll: ScrollView
    lateinit var root: LinearLayout

    fun label(value: String, sp: Int, color: Int = ink, serif: Boolean = false) =
        TextView(this).apply {
            text = value
            textSize = sp.toFloat()
            setTextColor(color)
            typeface = if (serif) Typeface.SERIF else Typeface.create("sans-serif", Typeface.NORMAL)
            setLineSpacing(dp(2).toFloat(), 1f)
        }

    fun begin(section: String, title: String, subtitle: String) {
        applyPalette()
        root =
            LinearLayout(this).apply {
                orientation = 1
                setBackgroundColor(paper)
            }
        root.setOnApplyWindowInsetsListener { v, ins ->
            @Suppress("DEPRECATION")
            v.setPadding(
                ins.systemWindowInsetLeft,
                ins.systemWindowInsetTop,
                ins.systemWindowInsetRight,
                ins.systemWindowInsetBottom,
            )
            ins
        }
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                (if (darkPalette) 0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        setContentView(root)
        scroll = ScrollView(this).apply { isFillViewport = true }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        body =
            LinearLayout(this).apply {
                orientation = 1
                setPadding(dp(16), dp(14), dp(16), dp(12))
            }
        scroll.addView(body)
        val hero =
            FrameLayout(this).apply {
                background = bg(heroColor, dp(22).toFloat())
                clipToOutline = true
            }
        body.addView(hero)
        hero.addView(TileArt(this), FrameLayout.LayoutParams(-1, -1))
        val block =
            LinearLayout(this).apply {
                orientation = 1
                setPadding(dp(22), dp(20), dp(22), dp(20))
            }
        hero.addView(block)
        block.addView(label(section.uppercase(), 12, gold).apply { letterSpacing = .14f })
        block.addView(label(title, 34, 0xfffffcf4.toInt(), true))
        block.addView(label(subtitle, 14, 0xffdeebe1.toInt()))
    }

    fun card(): LinearLayout {
        val panel =
            LinearLayout(this).apply {
                orientation = 1
                background =
                    bg(surfaceColor, dp(16).toFloat()).apply {
                        setStroke(dp(1), controlColor)
                    }
                setPadding(dp(16), dp(14), dp(16), dp(14))
            }
        body.addView(panel, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        return panel
    }

    fun action(parent: LinearLayout, title: String, click: () -> Unit) {
        parent.addView(
            Button(this).apply {
                text = title
                isAllCaps = false
                setTextColor(ink)
                minHeight = dp(48)
                backgroundTintList = android.content.res.ColorStateList.valueOf(controlColor)
                setOnClickListener { click() }
            }
        )
    }

    fun entry(title: String, detail: String, icon: Int = 0, click: () -> Unit) {
        card().apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            if (icon != 0) {
                val badge =
                    ImageView(context).apply {
                        setImageResource(icon)
                        setColorFilter(ink)
                        background = bg(controlColor, dp(13).toFloat())
                        setPadding(dp(8), dp(8), dp(8), dp(8))
                        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                    }
                addView(
                    badge,
                    LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(12) },
                )
            }
            val copy = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
            copy.addView(label(title, 21, ink, true))
            copy.addView(label(detail, 14, muted))
            addView(copy, LinearLayout.LayoutParams(0, -2, 1f))
            addView(
                label("›", 25, ink).apply {
                    gravity = Gravity.CENTER
                    background = bg(controlColor, dp(15).toFloat())
                    importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                },
                LinearLayout.LayoutParams(dp(32), dp(32)),
            )
            isFocusable = true
            setOnClickListener { click() }
            val value = android.util.TypedValue()
            theme.resolveAttribute(android.R.attr.selectableItemBackground, value, true)
            foreground = getDrawable(value.resourceId)
        }
    }

    fun rtl(panel: LinearLayout, value: String, size: Int) {
        panel.addView(
            label(value, size).apply {
                typeface = readingTypeface
                textDirection = View.TEXT_DIRECTION_RTL
                gravity = Gravity.RIGHT
                setTextIsSelectable(true)
                setLineSpacing(dp(5).toFloat(), 1.15f)
            }
        )
    }
}

fun MainActivity.readingTiles() {
    val row = LinearLayout(this)
    body.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
    fun tile(
        title: String,
        secondary: String,
        info: String,
        tone: Int,
        foreground: Int,
        open: () -> Unit,
    ) {
        val tile =
            LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = bg(tone, dp(20).toFloat())
                setPadding(dp(15), dp(17), dp(12), dp(17))
                isFocusable = true
                setOnClickListener { open() }
            }
        row.addView(
            tile,
            LinearLayout.LayoutParams(0, -1, 1f).apply {
                if (row.childCount > 0) leftMargin = dp(8)
            },
        )
        tile.addView(label(secondary, 16, foreground, true))
        tile.addView(label(title, 22, foreground, true))
        tile.addView(label(info, 13, foreground))
    }
    tile(
        l("Recite the Quran", "د قرآن تلاوت"),
        l("Recitation", "تلاوت"),
        l("Resume page ", "له پاڼې دوام: ") + prefs.getInt("mushafPage", 1),
        controlColor,
        ink,
    ) {
        go("mushaf")
    }
    tile(
        l("Quran with translation", "قرآن له ژباړې سره"),
        l("Study", "ژباړه"),
        editionCredit(),
        surfaceColor,
        ink,
    ) {
        prefs.edit().putBoolean("pashto", true).apply()
        go("translationIndex")
    }
}
