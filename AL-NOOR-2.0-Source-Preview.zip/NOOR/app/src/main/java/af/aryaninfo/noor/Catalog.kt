package af.aryaninfo.noor

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.util.Xml
import java.io.File
import org.json.JSONArray
import org.xmlpull.v1.XmlPullParser

data class Verse(
    val arabic: String,
    val pashto: String,
    val note: String,
    val english: String,
    val enNote: String,
    val dari: String = "",
    val dariNote: String = "",
)

data class Surah(
    val id: Int,
    val name: String,
    val arabic: String,
    val meaning: String,
    val verses: List<Verse>,
)

data class Invocation(val id: Int, val text: String, val repeats: Int)

data class Chapter(val id: Int, val title: String, val entries: List<Invocation>)

data class Catalog(val surahs: List<Surah>, val chapters: List<Chapter>) {
    companion object {
        @Volatile private var cached: Catalog? = null

        @Synchronized
        fun load(context: Context): Catalog {
            cached?.let {
                return it
            }
            val assets = context.assets
            val arabic =
                assets.open("quran.txt").bufferedReader().useLines { lines ->
                    lines
                        .filter { it.firstOrNull()?.isDigit() == true }
                        .associate {
                            val parts = it.split('|', limit = 3)
                            (parts[0].toInt() to parts[1].toInt()) to parts[2]
                        }
                }
            fun edition(asset: String, version: String): Map<Pair<Int, Int>, Pair<String, String>> {
                val path = File(context.cacheDir, "$version-$asset")
                if (!path.exists()) {
                    val temp = File.createTempFile("edition", ".tmp", context.cacheDir)
                    try {
                        assets.open(asset).use { src -> temp.outputStream().use { src.copyTo(it) } }
                        check(temp.renameTo(path))
                    } finally {
                        temp.delete()
                    }
                }
                val rows = mutableMapOf<Pair<Int, Int>, Pair<String, String>>()
                SQLiteDatabase.openDatabase(path.path, null, SQLiteDatabase.OPEN_READONLY).use { db
                    ->
                    db.rawQuery(
                            "SELECT sura,aya,translation,footnotes FROM translations ORDER BY sura,aya",
                            null,
                        )
                        .use { c ->
                            while (c.moveToNext()) rows[c.getInt(0) to c.getInt(1)] =
                                c.getString(2) to c.getString(3).orEmpty()
                        }
                }
                check(rows.keys == arabic.keys)
                return rows
            }
            val ps = edition("pashto_rwwad.sqlite", "1.0.1")
            val en = edition("english_saheeh.sqlite", "1.1.2")
            val da = if (assets.list("")?.contains("dari_badkhashani.sqlite") == true)
                edition("dari_badkhashani.sqlite", "1.0.0") else emptyMap()
            val grouped =
                arabic.entries.groupBy({ it.key.first }) { (key, ar) ->
                    val p = ps.getValue(key)
                    val e = en.getValue(key)
                    Verse(ar, p.first, p.second, e.first, e.second, da[key]?.first.orEmpty(), da[key]?.second.orEmpty())
                }
            val surahs = mutableListOf<Surah>()
            assets.open("meta.xml").use { input ->
                val parser = Xml.newPullParser()
                parser.setInput(input, "UTF-8")
                while (parser.next() != XmlPullParser.END_DOCUMENT) {
                    if (parser.eventType == XmlPullParser.START_TAG && parser.name == "sura") {
                        fun attr(name: String) = parser.getAttributeValue(null, name)
                        val id = attr("index").toInt()
                        val list = grouped.getValue(id)
                        check(list.size == attr("ayas").toInt())
                        surahs.add(Surah(id, attr("tname"), attr("name"), attr("ename"), list))
                    }
                }
            }
            check(surahs.size == 114 && arabic.size == 6236)
            val data = JSONArray(assets.open("hisn.json").bufferedReader().use { it.readText() })
            val chapters =
                (0 until data.length()).map { i ->
                    val item = data.getJSONObject(i)
                    val rows = item.getJSONArray("entries")
                    Chapter(
                        item.getInt("id"),
                        item.getString("title"),
                        (0 until rows.length()).map { j ->
                            val row = rows.getJSONObject(j)
                            Invocation(
                                row.getInt("id"),
                                row.getString("arabic"),
                                row.optInt("repeat", 1).coerceAtLeast(1),
                            )
                        },
                    )
                }
            return Catalog(surahs, chapters).also { cached = it }
        }
    }
}
