package af.aryaninfo.noor

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import java.time.*
import java.util.Locale

private val themes =
    listOf(
        94 to 5,
        94 to 6,
        93 to 5,
        20 to 114,
        2 to 152,
        2 to 153,
        39 to 53,
        13 to 28,
        65 to 3,
        3 to 139,
        11 to 115,
        29 to 69,
        16 to 97,
        14 to 7,
        53 to 39,
        3 to 200,
        76 to 24,
        25 to 63,
        41 to 34,
        31 to 17,
        73 to 8,
        17 to 82,
        15 to 98,
        30 to 60,
        2 to 186,
        3 to 160,
        7 to 56,
        33 to 41,
        50 to 39,
        24 to 56,
        40 to 60,
    )

fun dailyVerse(date: LocalDate = LocalDate.now()) =
    themes[Math.floorMod(date.toEpochDay(), themes.size.toLong()).toInt()]

class DailyReminder : BroadcastReceiver() {
    companion object {
        val types = listOf("adhkar", "ayah", "recite")

        fun title(c: Context, key: String) =
            mapOf(
                    "adhkar" to c.l("Daily adhkar", "ورځني اذکار"),
                    "ayah" to c.l("Ayah of the day", "د نن ورځې آیت"),
                    "recite" to c.l("Daily recitation", "ورځنی تلاوت"),
                )
                .getValue(key)

        val hours = mapOf("adhkar" to 7, "ayah" to 8, "recite" to 20)

        fun schedule(c: Context, only: String? = null) {
            val p = c.getSharedPreferences("noor", Context.MODE_PRIVATE)
            val alarm = c.getSystemService(AlarmManager::class.java)
            types.forEachIndexed { index, type ->
                if (only != null && type != only) return@forEachIndexed
                val intent =
                    PendingIntent.getBroadcast(
                        c,
                        30 + index,
                        Intent(c, DailyReminder::class.java).setAction("af.aryaninfo.noor.$type"),
                        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
                    )
                alarm.cancel(intent)
                if (p.getBoolean("enabled/$type", false)) {
                    val now = ZonedDateTime.now()
                    val local =
                        LocalTime.of(
                            p.getInt("hour/$type", hours.getValue(type)),
                            p.getInt("minute/$type", 0),
                        )
                    var next = now.toLocalDate().atTime(local).atZone(now.zone)
                    if (!next.isAfter(now))
                        next = now.toLocalDate().plusDays(1).atTime(local).atZone(now.zone)
                    alarm.setAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        next.toInstant().toEpochMilli(),
                        intent,
                    )
                }
            }
        }
    }

    override fun onReceive(c: Context, i: Intent) {
        val type = i.action?.removePrefix("af.aryaninfo.noor.")
        if (type !in types) {
            schedule(c)
            return
        }
        val kind = type!!
        val prefs = c.getSharedPreferences("noor", 0)
        if (!prefs.getBoolean("enabled/$kind", false)) return
        // Reschedule only this alarm after delivery so two reminders may share a time.
        val pending = goAsync()
        Thread {
                try {
                    val manager = c.getSystemService(NotificationManager::class.java)
                    manager.createNotificationChannel(
                        NotificationChannel(
                            kind,
                            title(c, kind),
                            NotificationManager.IMPORTANCE_DEFAULT,
                        )
                    )
                    if (manager.areNotificationsEnabled()) {
                        val index = types.indexOf(kind)
                        val target =
                            Intent(c, MainActivity::class.java).putExtra("destination", kind)
                        var title = title(c, kind)
                        var message =
                            if (kind == "recite")
                                c.l(
                                    "Continue your Quran reading from your saved ayah.",
                                    "خپل تلاوت له خوندي شوي ځایه پیل کړئ.",
                                )
                            else
                                c.l(
                                    "Open your morning and evening remembrances.",
                                    "د سهار او ماښام اذکار پرانیزئ.",
                                )
                        if (kind == "ayah") {
                            val (s, a) = dailyVerse()
                            val v = Catalog.load(c).surahs[s - 1].verses[a - 1]
                            title += "   ·   $s:$a"
                            message =
                                v.arabic +
                                    "\n" +
                                    c.meaning(v) +
                                    if (c.footnote(v).isEmpty()) "" else "\n" + c.footnote(v)
                            target.putExtra("surah", s).putExtra("ayah", a)
                        }
                        val open =
                            PendingIntent.getActivity(
                                c,
                                40 + index,
                                target,
                                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
                            )
                        manager.notify(
                            40 + index,
                            Notification.Builder(c, kind)
                                .setSmallIcon(R.drawable.reminder)
                                .setSubText(
                                    if (kind == "ayah")
                                        c.l(
                                            "Noor International · QuranEnc 1.1.2",
                                            "رواد · قرآن اېنسایکلوپیډیا ۱.۰.۱",
                                        )
                                    else c.l("Al Noor", "النور")
                                )
                                .setContentTitle(title)
                                .setContentText(message)
                                .setStyle(Notification.BigTextStyle().bigText(message))
                                .setContentIntent(open)
                                .setAutoCancel(true)
                                .build(),
                        )
                    }
                } finally {
                    schedule(c, kind)
                    pending.finish()
                }
            }
            .start()
    }
}

fun MainActivity.settingsScreen() {
    begin(
        l("Aryan Info-Tech", "آریان انفوتېک"),
        l("Settings & sources", "تنظیمات او سرچینې"),
        l("Reading preferences and daily reminders", "د لوست تنظیمات او ورځنۍ یادونې"),
    )
    val read = card()
    read.addView(label(l("Arabic reading size", "د عربي لیک اندازه"), 21, ink, true))
    action(read, "${prefs.getInt("size",27)} sp" + l(" · Change", " · بدلول")) {
        val sizes = listOf(22, 27, 32, 38)
        AlertDialog.Builder(this)
            .setTitle(l("Arabic text size", "د عربي لیک اندازه"))
            .setItems(sizes.map { "$it sp" }.toTypedArray()) { _, i ->
                prefs.edit().putInt("size", sizes[i]).apply()
                render()
            }
            .show()
    }
    val allowed = getSystemService(NotificationManager::class.java).areNotificationsEnabled()
    for (type in DailyReminder.types) {
        val reminder = card()
        reminder.addView(label(DailyReminder.title(this, type), 21, ink, true))
        val enabled = prefs.getBoolean("enabled/$type", false)
        val hour = prefs.getInt("hour/$type", DailyReminder.hours.getValue(type))
        val minute = prefs.getInt("minute/$type", 0)
        val time = String.format(Locale.ENGLISH, "%02d:%02d", hour, minute)
        reminder.addView(
            label(
                if (enabled && allowed)
                    l(
                        "On   ·   Around $time, device local time",
                        "فعال · د موبایل په سیمه ییز وخت شاوخوا $time",
                    )
                else if (enabled)
                    l("Notifications blocked by Android", "اندروید خبرتیاوې بندې کړې دي")
                else l("Off", "بند"),
                16,
                muted,
            )
        )
        action(
            reminder,
            if (enabled) l("Change time", "وخت بدل کړئ") else l("Set daily time", "ورځنی وخت وټاکئ"),
        ) {
            TimePickerDialog(
                    this,
                    { _, h, m ->
                        prefs
                            .edit()
                            .putInt("hour/$type", h)
                            .putInt("minute/$type", m)
                            .putBoolean("enabled/$type", true)
                            .apply()
                        if (
                            Build.VERSION.SDK_INT >= 33 &&
                                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
                                    PackageManager.PERMISSION_GRANTED
                        )
                            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 58)
                        DailyReminder.schedule(this, type)
                        render()
                    },
                    hour,
                    minute,
                    true,
                )
                .show()
        }
        if (enabled)
            action(reminder, l("Turn off", "بندول")) {
                prefs.edit().putBoolean("enabled/$type", false).apply()
                DailyReminder.schedule(this, type)
                render()
            }
    }
    action(card(), l("Android notification settings", "د اندروید د خبرتیاوو تنظیمات")) {
        startActivity(
            Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, packageName)
        )
    }
    action(card(), l("Sources & editions", "سرچینې او چاپونه")) { go("legal") }
}

fun MainActivity.guideScreen() = wuduGuide()
