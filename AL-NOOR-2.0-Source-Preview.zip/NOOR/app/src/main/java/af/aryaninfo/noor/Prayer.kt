package af.aryaninfo.noor

import android.app.AlertDialog
import android.content.Context
import android.graphics.*
import android.hardware.*
import android.view.*
import android.widget.*
import com.batoulapps.adhan.*
import com.batoulapps.adhan.data.DateComponents
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.Locale

data class Place(val name: String, val lat: Double, val lon: Double, val zone: ZoneId)

private val kabulZone = ZoneId.of("Asia/Kabul")
private val cities =
    listOf(
        Place("Kabul", 34.5553, 69.2075, kabulZone),
        Place("Jalalabad", 34.4265, 70.4515, kabulZone),
        Place("Herat", 34.3529, 62.2040, kabulZone),
        Place("Kandahar", 31.6289, 65.7372, kabulZone),
        Place("Mazar-i-Sharif", 36.7069, 67.1122, kabulZone),
    )

fun MainActivity.city(): Place {
    if (prefs.getString("city", "Kabul") == "Custom")
        return Place(
            "Custom",
            prefs.getString("lat", "0")!!.toDouble(),
            prefs.getString("lon", "0")!!.toDouble(),
            ZoneId.of(prefs.getString("zone", "UTC")),
        )
    return cities.firstOrNull { it.name == prefs.getString("city", "Kabul") } ?: cities.first()
}

private fun MainActivity.selectPlace() {
    AlertDialog.Builder(this)
        .setTitle(l("Prayer location", "د لمانځه ځای"))
        .setItems(
            (cities.map { placeLabel(it.name) } + l("Custom coordinates", "خپل مختصات"))
                .toTypedArray()
        ) { _, i ->
            if (i < cities.size) {
                prefs.edit().putString("city", cities[i].name).apply()
                render()
            } else {
                val form =
                    LinearLayout(this).apply {
                        orientation = 1
                        setPadding(dp(20), 0, dp(20), 0)
                    }
                fun field(title: String, text: String) =
                    EditText(this).apply {
                        hint = title
                        setText(text)
                        isSingleLine = true
                        form.addView(this)
                    }
                val current = city()
                val lat = field(l("Latitude", "عرض البلد"), current.lat.toString())
                val lon = field(l("Longitude", "طول البلد"), current.lon.toString())
                val zone =
                    field(
                        l("Time zone, e.g. Asia/Kabul", "وخت سیمه، لکه Asia/Kabul"),
                        current.zone.id,
                    )
                val d =
                    AlertDialog.Builder(this)
                        .setTitle(l("Coordinates & time zone", "مختصات او وخت سیمه"))
                        .setView(form)
                        .setPositiveButton(l("Save", "خوندي کول"), null)
                        .setNegativeButton(l("Cancel", "لغوه"), null)
                        .create()
                d.setOnShowListener {
                    d.getButton(-1).setOnClickListener {
                        val a = lat.text.toString().toDoubleOrNull()
                        val b = lon.text.toString().toDoubleOrNull()
                        val z = runCatching { ZoneId.of(zone.text.toString().trim()) }.getOrNull()
                        when {
                            a == null || a !in -90.0..90.0 ->
                                lat.error = l("Use −90 to 90", "له منفي ۹۰ تر ۹۰ پورې")
                            b == null || b !in -180.0..180.0 ->
                                lon.error = l("Use −180 to 180", "له منفي ۱۸۰ تر ۱۸۰ پورې")
                            z == null ->
                                zone.error = l("Enter a valid time zone", "سمه وخت سیمه ولیکئ")
                            else -> {
                                prefs
                                    .edit()
                                    .putString("city", "Custom")
                                    .putString("lat", a.toString())
                                    .putString("lon", b.toString())
                                    .putString("zone", z.id)
                                    .apply()
                                d.dismiss()
                                render()
                            }
                        }
                    }
                }
                d.show()
            }
        }
        .show()
}

fun MainActivity.prayerScreen() {
    val place = city()
    val date = LocalDate.now(place.zone)
    val coords = Coordinates(place.lat, place.lon)
    val method = CalculationMethod.valueOf(prefs.getString("method", "KARACHI")!!)
    begin(
        l("Worship", "عبادت"),
        l("Prayer times", "د لمانځه وختونه"),
        placeLabel(place.name) + "   ·   " + date.toString() + "   ·   " + place.zone.id,
    )
    prayerSummary(card())
    val config = card()
    action(config, l("Change location   ·   ", "ځای بدل کړئ · ") + placeLabel(place.name)) {
        selectPlace()
    }
    action(config, l("Method   ·   ", "د حساب طریقه · ") + placeLabel(method.name)) {
        val choices =
            listOf(
                CalculationMethod.KARACHI,
                CalculationMethod.MUSLIM_WORLD_LEAGUE,
                CalculationMethod.UMM_AL_QURA,
            )
        AlertDialog.Builder(this)
            .setTitle(l("Calculation method", "د وختونو د حساب طریقه"))
            .setItems(choices.map { placeLabel(it.name) }.toTypedArray()) { _, i ->
                prefs.edit().putString("method", choices[i].name).apply()
                render()
            }
            .show()
    }
    config.addView(
        label(
            l(
                "Hanafi Asr   ·   Calculated start times",
                "حنفي عصر · د لمانځه د پیل حساب شوي وختونه",
            ),
            14,
            muted,
        )
    )
    val online = onlineTimetable(config, place, date, method)
    val schedule = card()
    val times =
        runCatching {
                PrayerTimes(
                    coords,
                    DateComponents(date.year, date.monthValue, date.dayOfMonth),
                    method.parameters.apply { madhab = Madhab.HANAFI },
                )
            }
            .getOrNull()
    val formatter = DateTimeFormatter.ofPattern("HH:mm").withZone(place.zone)
    listOf(
            "Fajr" to times?.fajr,
            "Sunrise" to times?.sunrise,
            "Dhuhr" to times?.dhuhr,
            "Asr" to times?.asr,
            "Maghrib" to times?.maghrib,
            "Isha" to times?.isha,
        )
        .forEach { (name, time) ->
            val row = LinearLayout(this)
            schedule.addView(row)
            row.setPadding(0, dp(5), 0, dp(5))
            row.addView(label(placeLabel(name), 19), LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(
                label(
                    online?.getString(name)
                        ?: time?.let { formatter.format(it.toInstant()) }
                        ?: l("Unavailable", "وخت نشته"),
                    19,
                    ink,
                    true,
                )
            )
        }
    val direction = Qibla(coords).direction
    val box = card()
    box.addView(label(l("Qibla", "قبله"), 23, ink, true))
    box.addView(
        label(
            String.format(
                Locale.ENGLISH,
                l(
                    "%.1f° clockwise from true north",
                    "له حقیقي شمال څخه د ساعت د ستنې پر لور %.1f درجې",
                ),
                (direction + 360) % 360,
            ),
            17,
        )
    )
    box.addView(QiblaDial(this, place, direction), LinearLayout.LayoutParams(-1, dp(170)))
    box.addView(
        label(
            l(
                "Hold the phone flat. With no heading sensor, align the top of the phone with true north.",
                "موبایل هوار ونیسئ. که د لوري حسګر نه لري، د موبایل سر حقیقي شمال ته برابر کړئ.",
            ),
            14,
            muted,
        )
    )
}

private class QiblaDial(context: Context, place: Place, private val direction: Double) :
    View(context), SensorEventListener {
    private val manager = context.getSystemService(SensorManager::class.java)
    private val sensor = manager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    private val correction =
        GeomagneticField(place.lat.toFloat(), place.lon.toFloat(), 0f, System.currentTimeMillis())
            .declination
    private var heading = 0f
    private var live = false
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun updateSensor() {
        manager.unregisterListener(this)
        if (isAttachedToWindow && windowVisibility == VISIBLE)
            sensor?.let { manager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        updateSensor()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (isAttachedToWindow) updateSensor()
    }

    override fun onDetachedFromWindow() {
        manager.unregisterListener(this)
        super.onDetachedFromWindow()
    }

    override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}

    override fun onSensorChanged(e: SensorEvent) {
        val m = FloatArray(9)
        SensorManager.getRotationMatrixFromVector(m, e.values)
        @Suppress("DEPRECATION")
        val rotation =
            (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager)
                .defaultDisplay
                .rotation
        val axes =
            when (rotation) {
                Surface.ROTATION_90 -> SensorManager.AXIS_Y to SensorManager.AXIS_MINUS_X
                Surface.ROTATION_180 -> SensorManager.AXIS_MINUS_X to SensorManager.AXIS_MINUS_Y
                Surface.ROTATION_270 -> SensorManager.AXIS_MINUS_Y to SensorManager.AXIS_X
                else -> SensorManager.AXIS_X to SensorManager.AXIS_Y
            }
        val out = FloatArray(9)
        SensorManager.remapCoordinateSystem(m, axes.first, axes.second, out)
        heading =
            Math.toDegrees(SensorManager.getOrientation(out, FloatArray(3))[0].toDouble())
                .toFloat() + correction
        live = e.accuracy != SensorManager.SENSOR_STATUS_UNRELIABLE
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val radius = minOf(width, height) * .32f
        val x = width / 2f
        val y = height * .45f
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        paint.color = muted
        c.drawCircle(x, y, radius, paint)
        c.save()
        c.rotate(direction.toFloat() - (if (live) heading else 0f), x, y)
        paint.style = Paint.Style.FILL
        paint.color = ink
        val arrow =
            Path().apply {
                moveTo(x, y - radius)
                lineTo(x + radius * .26f, y + radius * .45f)
                lineTo(x, y + radius * .2f)
                lineTo(x - radius * .26f, y + radius * .45f)
                close()
            }
        c.drawPath(arrow, paint)
        c.restore()
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = 14 * resources.displayMetrics.scaledDensity
        c.drawText(
            if (live) context.l("Live heading", "اوسنی لوری")
            else context.l("True north at top", "پورته حقیقي شمال دی"),
            x,
            height * .96f,
            paint,
        )
    }
}

internal fun Context.placeLabel(key: String): String {
    val labels =
        mapOf(
            "Kabul" to "کابل",
            "Jalalabad" to "جلال اباد",
            "Herat" to "هرات",
            "Kandahar" to "کندهار",
            "Mazar-i-Sharif" to "مزار شریف",
            "Custom" to "ټاکلی ځای",
            "Fajr" to "سهار",
            "Sunrise" to "لمر ختل",
            "Dhuhr" to "ماسپښین",
            "Asr" to "مازدیګر",
            "Maghrib" to "ماښام",
            "Isha" to "ماسخوتن",
            "KARACHI" to "کراچۍ",
            "MUSLIM_WORLD_LEAGUE" to "رابطه عالم اسلامي",
            "UMM_AL_QURA" to "ام القری",
        )
    val translated = mapOf("Fajr" to ("صبح" to "الفجر"), "Sunrise" to ("طلوع آفتاب" to "الشروق"), "Dhuhr" to ("ظهر" to "الظهر"), "Asr" to ("عصر" to "العصر"), "Maghrib" to ("شام" to "المغرب"), "Isha" to ("خفتن" to "العشاء"))
    translated[key]?.let { return t4(key, labels[key] ?: key, it.first, it.second) }
    return l(
        if (key == key.uppercase()) key.lowercase().replace('_', ' ') else key,
        labels[key] ?: key,
    )
}
