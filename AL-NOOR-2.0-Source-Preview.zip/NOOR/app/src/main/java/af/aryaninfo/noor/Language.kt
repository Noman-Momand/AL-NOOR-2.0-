package af.aryaninfo.noor

import android.app.AlertDialog
import android.content.Context
import android.view.View
import android.widget.*
import java.util.Locale

val Context.language: String
    get() = getSharedPreferences("noor", 0).getString("language", "en") ?: "en"
val Context.translationLanguage: String
    get() = getSharedPreferences("noor", 0).getString("translationLanguage", "auto").let { if (it == null || it == "auto") language else it }
fun Context.t4(en: String, pashto: String, dari: String, arabic: String) = when(language) { "ps" -> pashto; "prs" -> dari; "ar" -> arabic; else -> en }
val Context.ps: Boolean
    get() = getSharedPreferences("noor", 0).getString("language", "en") == "ps"

fun Context.l(en: String, pashto: String) = when(language) { "ps" -> pashto; "prs" -> uiWords[en]?.first ?: en; "ar" -> uiWords[en]?.second ?: en; else -> en }

val Context.uiLocale: Locale
    get() = Locale.forLanguageTag(when(language) { "ps" -> "ps-AF"; "prs" -> "fa-AF"; "ar" -> "ar"; else -> "en" })

fun Context.titleOf(s: Surah) = if (language != "en") s.arabic else s.name

fun Context.meaning(v: Verse) = when(translationLanguage) { "ps" -> v.pashto; "prs" -> v.dari; "ar" -> ""; else -> v.english }

fun Context.footnote(v: Verse) = when(translationLanguage) { "ps" -> v.note; "prs" -> v.dariNote; "ar" -> ""; else -> v.enNote }

fun MainActivity.translation(panel: LinearLayout, v: Verse) {
    val size = prefs.getInt("size", 27) - 5
    if (translationLanguage == "prs" && v.dari.isEmpty()) {
        panel.addView(label(t4("Dari edition is not installed. Read at the publisher.", "د دري ژباړه لا نشته.", "نسخه دری نصب نشده است. در وبگاه ناشر بخوانید.", "نسخة الدارية غير مثبتة."), 15, muted))
        action(panel, "QuranEnc · محمد انور بدخشانی") { openPublisher() }
        return
    }
    for ((value, sp) in listOf(meaning(v) to size, footnote(v) to 16)) if (value.isNotEmpty()) {
        if (translationLanguage != "en") rtl(panel, value, sp)
        else
            panel.addView(
                label(value, sp).apply {
                    setTextIsSelectable(true)
                    textDirection = View.TEXT_DIRECTION_LTR
                }
            )
    }
}

fun opening(ref: Ref, arabic: String): String {
    if (ref.a != 1 || ref.s == 1 || ref.s == 9) return arabic
    var pos = -1
    repeat(4) {
        pos = arabic.indexOf(' ', pos + 1)
        if (pos < 0) return arabic
    }
    return arabic.substring(0, pos) + "\n\n" + arabic.substring(pos + 1)
}

fun MainActivity.languageMenu() {
    AlertDialog.Builder(this)
        .setTitle("Language · ژبه · زبان · اللغة")
        .setSingleChoiceItems(arrayOf("English", "پښتو", "دری", "العربية"), listOf("en", "ps", "prs", "ar").indexOf(language)) { d, i ->
            prefs.edit().putString("language", listOf("en", "ps", "prs", "ar")[i]).apply()
            d.dismiss()
            recreate()
        }
        .show()
}

fun MainActivity.legalScreen() {
    begin(
        l("Information", "معلومات"),
        l("Privacy & notices", "محرمیت او خبرتیاوې"),
        l("Al Noor · Aryan Info-Tech", "النور · آریان انفوتېک"),
    )
    fun section(en: String, pt: String, body: String, pb: String) {
        val c = card()
        c.addView(label(l(en, pt), 22, ink, true))
        c.addView(label(l(body, pb), 16))
    }
    section(
        "Privacy policy",
        "د محرمیت تګلاره",
        "Reading positions, reminders, bookmarks, language and counters are stored on this device. Al Noor has no accounts, advertising or analytics. Notifications appear according to your Android settings.",
        "د لوست ځای، یادونې، نښې، ژبه او شمېرې په همدې وسیله ساتل کېږي. النور حسابونه، اعلانونه او د کارونې څارنه نه لري. خبرتیاوې د موبایل له تنظیماتو سره سم ښکاري.",
    )
    section(
        "Optional network use",
        "اختیاري انټرنېټ",
        "Refreshing prayer times sends the selected coordinates, date, calculation method and time zone to AlAdhan. Its server also receives your IP address. External source links open in your browser.",
        "د لمانځه د وختونو تازه کول ټاکلي مختصات، نېټه، د حساب طریقه او وخت سیمه الاذان ته لېږي. د خدمت سرور ستاسې د انټرنېټ پته هم ویني. د سرچینو تړنې په براوزر کې پرانیستل کېږي.",
    )
    section(
        "Keeping and deleting counts",
        "د شمېرو ساتل او ړنګول",
        "Choose a Tasbeeh backup in Documents to keep a copy outside the app. Counting updates that file. After reinstalling, choose Restore and select it again. Clearing app data removes private settings. Delete the saved file separately in Files.",
        "د تسبېح لپاره په اسنادو کې د شاتړ فایل وټاکئ. شمېرل دغه فایل هم تازه کوي. له بیا نصب وروسته د بېرته راګرځولو تڼۍ کې هماغه فایل وټاکئ. د اپ معلومات پاکول شخصي تنظیمات ړنګوي. د شاتړ فایل په جلا توګه له خپلو فایلونو ړنګولی شئ.",
    )
    section(
        "Editions and attribution",
        "چاپونه او سرچینې",
        "Arabic Quran: Tanzil Uthmani 1.1. English meanings: Noor International Center, QuranEnc 1.1.2. Pashto meanings: Rowwad Translation Center, QuranEnc 1.0.1. Both editions include publisher footnotes. Hisn al-Muslim: Saʿīd al-Qaḥṭānī, with complete English and Pashto editions from IslamHouse. Entry 197 was cross-checked against Sunnah.com.",
        "عربي قرآن د تنزیل عثماني متن ۱.۱ دی. انګلیسي ژباړه د نور نړیوال مرکز ۱.۱.۲ او پښتو ژباړه د رواد ژباړې مرکز ۱.۰.۱ ده؛ دواړه له قرآن اېنسایکلوپیډیا څخه د خپروونکي له حاشیو سره اخیستل شوې دي. حصن المسلم د سعید القحطاني اثر دی. بشپړ پښتو او انګلیسي چاپونه له اسلام هاوس څخه دي. ۱۹۷مه دعا له سنت ډاټ کام سره کتل شوې ده.",
    )
    section(
        "Use and rights",
        "کارونه او حقونه",
        "The app is an educational aid. Prayer times are calculated and may differ from a local mosque. Consult a qualified teacher for personal fiqh questions. Publishers retain their respective rights. No endorsement by the publishers is implied.",
        "دا اپ د زده کړې وسیله ده. د لمانځه وختونه حسابېږي او ښايي د جومات له مهالوېش سره توپیر ولري. د شخصي فقهي پوښتنو لپاره له باوري عالم سره مشوره وکړئ. د هر اثر حقونه د هغه د خپروونکي دي. دا اپ د خپروونکو د تأیید ادعا نه کوي.",
    )
    val da = card()
    da.addView(label("Dari Quran · Muhammad Anwar Badakhshani · QuranEnc 1.0.0", 18))
    action(da,"QuranEnc · دری") { openPublisher() }
    if(assets.list("")?.contains("dari-publisher-notice.txt") == true) action(da,"Dari publisher notice") {
        AlertDialog.Builder(this).setMessage(assets.open("dari-publisher-notice.txt").bufferedReader().use { it.readText() }).setPositiveButton(android.R.string.ok,null).show()
    }
    val c = card()
    val links =
        label(
            "https://tanzil.net\nhttps://quranenc.com/en/browse/english_saheeh\nhttps://quranenc.com/ps/browse/pashto_rwwad\nhttps://quranenc.com/en/contact\nhttps://islamhouse.com\nhttps://aladhan.com",
            15,
        )
    android.text.util.Linkify.addLinks(links, android.text.util.Linkify.WEB_URLS)
    c.addView(links)
    action(c, l("Original license notices", "د جوازونو اصلي متنونه")) {
        val files = listOf("quran.txt", "OFL.txt", "ADHAN-LICENSE.txt")
        val notices =
            files.joinToString("\n\n") { name ->
                assets.open(name).bufferedReader().use { r ->
                    if (name == "quran.txt")
                        r.lineSequence().filter { it.startsWith("#") }.joinToString("\n")
                    else r.readText()
                }
            }
        AlertDialog.Builder(this)
            .setTitle(l("Publisher notices", "د خپروونکو خبرتیاوې"))
            .setMessage(notices)
            .setPositiveButton(android.R.string.ok, null)
            .show()
    }
}
