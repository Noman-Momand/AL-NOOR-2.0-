package af.aryaninfo.noor

import android.app.AlertDialog
import android.icu.util.IslamicCalendar
import android.icu.util.TimeZone
import android.view.Gravity
import android.widget.*
import java.time.*
import java.time.format.DateTimeFormatter

private val months =
    listOf(
        "Muharram",
        "Safar",
        "Rabiʿ I",
        "Rabiʿ II",
        "Jumada I",
        "Jumada II",
        "Rajab",
        "Shaʿban",
        "Ramadan",
        "Shawwal",
        "Dhu al-Qaʿdah",
        "Dhu al-Hijjah",
    )

private fun MainActivity.islamic(date: LocalDate) =
    IslamicCalendar(TimeZone.getTimeZone("UTC")).apply {
        calculationType = IslamicCalendar.CalculationType.ISLAMIC_UMALQURA
        timeInMillis =
            date
                .plusDays(prefs.getInt("hijriOffset", 0).toLong())
                .atTime(12, 0)
                .toInstant(ZoneOffset.UTC)
                .toEpochMilli()
    }

fun MainActivity.hijri(date: LocalDate): String {
    val c = islamic(date)
    val names =
        if (language != "en")
            "محرم|صفر|ربیع الاول|ربیع الثاني|جمادی الاولی|جمادی الثاني|رجب|شعبان|رمضان|شوال|ذوالقعده|ذوالحجه"
                .split('|')
        else months
    return "${c.get(android.icu.util.Calendar.DAY_OF_MONTH)} ${names[c.get(android.icu.util.Calendar.MONTH)]} ${c.get(android.icu.util.Calendar.YEAR)} " +
        l("AH", "هـ ق")
}

fun MainActivity.calendarScreen() {
    begin(
        l("Calendar", "کلیز"),
        l("Islamic calendar", "هجري کلیز"),
        l("Umm al-Qura   ·   Civil-day display", "د ام القری حساب · مدني ورځ"),
    )
    val panel = card()
    panel.addView(
        label(month.format(DateTimeFormatter.ofPattern("MMMM yyyy", uiLocale)), 24, ink, true)
    )
    val controls = LinearLayout(this)
    panel.addView(controls)
    action(controls, l("‹ Prev", "مخکینۍ")) {
        month = month.minusMonths(1)
        selectedDate = month.atDay(1)
        render()
    }
    action(controls, l("Today", "نن")) {
        selectedDate = LocalDate.now(city().zone)
        month = YearMonth.from(selectedDate)
        render()
    }
    action(controls, l("Next ›", "بله")) {
        month = month.plusMonths(1)
        selectedDate = month.atDay(1)
        render()
    }
    val start = month.atDay(1).dayOfWeek.value - 1
    val headers = LinearLayout(this)
    panel.addView(headers)
    (if (ps) listOf("دو", "درې", "څلور", "پنځه", "جمعه", "شنبه", "یک")
        else listOf("M", "T", "W", "T", "F", "S", "S"))
        .forEach {
            headers.addView(
                label(it, 13, muted).apply { gravity = Gravity.CENTER },
                LinearLayout.LayoutParams(0, -2, 1f),
            )
        }
    for (w in 0 until (start + month.lengthOfMonth() + 6) / 7) {
        val row = LinearLayout(this)
        panel.addView(row)
        for (d in 0..6) {
            val n = w * 7 + d - start + 1
            val cell = label("", 15)
            row.addView(cell, LinearLayout.LayoutParams(0, dp(55), 1f))
            if (n in 1..month.lengthOfMonth()) {
                val day = month.atDay(n)
                cell.text = "$n\n" + islamic(day).get(android.icu.util.Calendar.DAY_OF_MONTH)
                cell.gravity = Gravity.CENTER
                if (day == selectedDate) cell.background = bg(0xffdbe9d9.toInt(), dp(9).toFloat())
                cell.contentDescription = "$day, " + hijri(day)
                cell.isFocusable = true
                cell.setOnClickListener {
                    selectedDate = day
                    render()
                }
            }
        }
    }
    val info = card()
    info.addView(label(hijri(selectedDate), 23, ink, true))
    info.addView(
        label(
            selectedDate.toString() +
                l("   ·   Gregorian above, Hijri below", " · پورته میلادي او لاندې هجري نېټه"),
            14,
            muted,
        )
    )
    info.addView(
        label(
            l(
                "Local moon sightings can shift the date. Adjust the calendar to match your community.",
                "سیمه ییزه میاشت لیدنه ښايي نېټه بدله کړي. کلیز د خپلې سیمې له مخې برابر کړئ.",
            ),
            15,
        )
    )
    action(
        info,
        l("Date adjustment   ·   ", "د نېټې سمون · ") +
            prefs.getInt("hijriOffset", 0) +
            l(" days", " ورځې"),
    ) {
        AlertDialog.Builder(this)
            .setTitle(l("Hijri date adjustment", "د هجري نېټې سمون"))
            .setItems(
                arrayOf(
                    l("−2 days", "منفي دوه ورځې"),
                    l("−1 day", "منفي یوه ورځ"),
                    l("No adjustment", "بې له بدلون"),
                    l("+1 day", "یوه ورځ وړاندې"),
                    l("+2 days", "دوه ورځې وړاندې"),
                )
            ) { _, i ->
                prefs.edit().putInt("hijriOffset", i - 2).apply()
                render()
            }
            .show()
    }
}
