package af.aryaninfo.noor

import android.app.AlertDialog
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import java.time.*
import java.time.format.DateTimeFormatter

class MainActivity : Screen() {
    override fun attachBaseContext(base: android.content.Context) {
        val cfg = android.content.res.Configuration(base.resources.configuration)
        cfg.setLocale(base.uiLocale)
        cfg.setLayoutDirection(base.uiLocale)
        super.attachBaseContext(base.createConfigurationContext(cfg))
    }

    val prefs by lazy { getSharedPreferences("noor", MODE_PRIVATE) }
    val chapterNames by lazy {
        assets.open("chapters-ps.txt").bufferedReader().use { it.readLines() }
    }

    fun chapterName(c: Chapter) = l(c.title, chapterNames[c.id - 1])

    val pageMap by lazy { PageMap(this) }
    lateinit var catalog: Catalog
    internal var route = "home"
    private var surah = 1
    private var ayah = 1
    internal var chapter = 27
    private var dailySurah = 1
    private var dailyAyah = 1
    private var query = ""
    var month: YearMonth = YearMonth.now()
    var selectedDate: LocalDate = LocalDate.now()
    private val trail = mutableListOf<String>()
    private val dateChange =
        object : android.content.BroadcastReceiver() {
            override fun onReceive(
                context: android.content.Context,
                intent: android.content.Intent,
            ) {
                if (route in listOf("home", "prayer", "calendar", "chapter")) render()
            }
        }

    override fun onStart() {
        super.onStart()
        val filter =
            android.content.IntentFilter(android.content.Intent.ACTION_DATE_CHANGED).apply {
                addAction(android.content.Intent.ACTION_TIMEZONE_CHANGED)
                addAction(android.content.Intent.ACTION_TIME_CHANGED)
            }
        if (android.os.Build.VERSION.SDK_INT >= 33)
            registerReceiver(dateChange, filter, RECEIVER_NOT_EXPORTED)
        else registerReceiver(dateChange, filter)
    }

    override fun onStop() {
        unregisterReceiver(dateChange)
        super.onStop()
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        surah = state?.getInt("surah") ?: prefs.getInt("surah", 1)
        ayah = state?.getInt("ayah") ?: prefs.getInt("ayah", 1)
        route =
            state?.getString("route")
                ?: when (intent.getStringExtra("destination")) {
                    "adhkar" -> "chapter"
                    "ayah" -> "daily"
                    "recite" ->
                        if (prefs.getString("lastReader", "reader") == "mushaf") "mushaf"
                        else "reader"
                    else -> "home"
                }
        dailySurah = state?.getInt("dailyS") ?: intent.getIntExtra("surah", dailyVerse().first)
        dailyAyah = state?.getInt("dailyA") ?: intent.getIntExtra("ayah", dailyVerse().second)
        chapter = state?.getInt("chapter") ?: 27
        query = state?.getString("query").orEmpty()
        state?.getStringArrayList("future")?.let { future.addAll(it) }
        state?.getStringArrayList("trail")?.let { trail.addAll(it) }
        month = YearMonth.parse(state?.getString("month") ?: YearMonth.now(city().zone).toString())
        selectedDate =
            LocalDate.parse(state?.getString("date") ?: LocalDate.now(city().zone).toString())
        begin(
            l("Aryan Info-Tech", "آریان انفوتېک"),
            l("Al Noor", "النور"),
            l("Created by Noman Momand", "جوړوونکی: نعمان مومند"),
        )
        Thread {
                val result = runCatching { Catalog.load(applicationContext) }
                runOnUiThread {
                    if (!isDestroyed && !isFinishing)
                        result
                            .onSuccess {
                                catalog = it
                                render()
                            }
                            .onFailure {
                                begin(
                                    l("Library", "کتابتون"),
                                    l("Content unavailable", "متن نه پرانیستل کېږي"),
                                    l(
                                        "The installed reading files could not be opened.",
                                        "د لوست فایلونه پرانیستل نه شول.",
                                    ),
                                )
                                action(card(), l("Try again", "بیا هڅه وکړئ")) { recreate() }
                            }
                }
            }
            .start()
    }

    override fun onSaveInstanceState(s: Bundle) {
        super.onSaveInstanceState(s)
        s.putInt("dailyS", dailySurah)
        s.putInt("dailyA", dailyAyah)
        s.putString("route", route)
        s.putInt("surah", surah)
        s.putInt("ayah", ayah)
        s.putInt("chapter", chapter)
        s.putString("query", query)
        s.putStringArrayList("future", ArrayList(future))
        s.putStringArrayList("trail", ArrayList(trail))
        s.putString("month", month.toString())
        s.putString("date", selectedDate.toString())
    }

    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: android.content.Intent?,
    ) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode in 813..814 && resultCode == RESULT_OK && data != null)
            counterFile(requestCode, data)
    }

    fun openTranslation(s: Int, a: Int) {
        surah = s
        ayah = a
        savePosition()
        prefs.edit().putBoolean("pashto", true).apply()
        go("reader")
    }

    fun trailEmpty() = trail.isEmpty()

    private var rustle: android.media.MediaPlayer? = null

    fun pageRustle() {
        rustle?.release()
        rustle =
            android.media.MediaPlayer.create(this, R.raw.page_turn)?.apply {
                setVolume(.45f, .45f)
                start()
            }
    }

    override fun onDestroy() {
        rustle?.release()
        rustle = null
        super.onDestroy()
    }

    val future = mutableListOf<String>()

    fun go(next: String) {
        if (next != route) future.clear()
        if (route != next) trail.add(route)
        route = next
        render()
    }

    @Deprecated("Platform back is supported on Android 8 and above")
    override fun onBackPressed() {
        if (trail.isEmpty()) finish()
        else {
            future.add(route)
            route = trail.removeAt(trail.lastIndex)
            render()
        }
    }

    fun render() {
        window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.attributes=window.attributes.apply { screenBrightness = -1f }
        if (!::catalog.isInitialized) return
        when (route) {
            "home" -> home()
            "daily" -> {
                begin(
                    l("Daily reflection", "ورځنی تدبر"),
                    l("Ayah of the day", "د نن ورځې آیت"),
                    t4("Arabic text and meaning", "عربي متن او پښتو ژباړه", "متن عربی و ترجمه دری", "النص القرآني"),
                )
                dailyCard(dailySurah, dailyAyah)
            }
            "quran" -> quranHub()
            "translationIndex" -> index()
            "mushaf" -> mushafReader()
            "juz" -> mushafIndex(true)
            "surahIndex" -> mushafIndex(false)
            "bookmarks" -> bookmarkList()
            "occasions" -> occasions()
            "founder" -> founder()
            "wudu" -> wuduGuide()
            "salah" -> salahGuide()
            "reader" -> reader()
            "tas" -> tasbeeh()
            "book" -> fullBook()
            "legal" -> legalScreen()
            "adhkar" -> adhkar()
            "chapter" -> invocations()
            "prayer" -> prayerScreen()
            "calendar" -> calendarScreen()
            "guides" -> guideScreen()
            "settings" -> settingsScreen()
            "themes" -> themeScreen()
            "ambient" -> ambientScreen()
            "ramadan" -> ramadanScreen()
            "journal" -> journalScreen()
            "memorize" -> memorizeScreen()
            "verseSearch" -> verseSearchScreen()
            else -> home()
        }
        if (route == "mushaf") return
        tintInputs(root)
        if (route != "home" || future.isNotEmpty()) {
            val history = LinearLayout(this)
            if (route != "home")
                action(history, l("‹ Back", "شاته")) {
                    if (trail.isEmpty()) go("home") else onBackPressed()
                }
            if (future.isNotEmpty())
                action(history, l("Forward ›", "مخکې")) {
                    trail.add(route)
                    route = future.removeAt(future.lastIndex)
                    render()
                }
            root.addView(history, 0)
        }
        val nav =
            LinearLayout(this).apply {
                setBackgroundColor(heroColor)
                gravity = Gravity.CENTER
            }
        root.addView(nav)
        listOf(
                "home" to l("Today", "نن"),
                "quran" to l("Quran", "قرآن"),
                "adhkar" to l("Adhkar", "اذکار"),
                "prayer" to l("Prayer", "لمونځ"),
            )
            .forEach { (key, title) ->
                val active =
                    key == route ||
                        (key == "quran" &&
                            route in
                                listOf(
                                    "reader",
                                    "translationIndex",
                                    "juz",
                                    "surahIndex",
                                    "bookmarks",
                                )) ||
                        (key == "adhkar" && route == "chapter")
                nav.addView(
                    label(title, 12, if (active) gold else 0xffffffff.toInt()).apply {
                        val resource =
                            when (key) {
                                "home" -> R.drawable.nav_today
                                "quran" -> R.drawable.nav_quran
                                "adhkar" -> R.drawable.nav_adhkar
                                else -> R.drawable.nav_prayer
                            }
                        val icon =
                            getDrawable(resource)!!.mutate().apply {
                                setTint(if (active) gold else 0xffdfebe2.toInt())
                                setBounds(0, 0, dp(20), dp(20))
                            }
                        setCompoundDrawables(null, icon, null, null)
                        setPadding(0, dp(7), 0, dp(5))
                        gravity = Gravity.CENTER
                        minHeight = dp(54)
                        isFocusable = true
                        isSelected = active
                        if (active) setTypeface(typeface, Typeface.BOLD)
                        setOnClickListener {
                            future.clear()
                            trail.clear()
                            if (key != "home") trail.add("home")
                            route = key
                            query = ""
                            render()
                        }
                    },
                    LinearLayout.LayoutParams(0, -2, 1f),
                )
            }
    }

    private fun home() {
        val today = LocalDate.now(city().zone)
        begin(
            l("Created by Noman Momand", "جوړوونکی: نعمان مومند"),
            l("Al Noor", "النور"),
            today.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", uiLocale)) +
                "  ·  " +
                hijri(today),
        )
        action(card(), "English · پښتو · دری · العربية") { languageMenu() }
        action(card(), t4("Themes & appearance", "بڼې او رنګونه", "تم‌ها و ظاهر", "المظهر والسمات")) { go("themes") }
        prayerSummary(card())
        companionTiles()
        readingTiles()
        val (ds, da) = dailyVerse()
        dailyCard(ds, da)
        entry(
            l("Digital Tasbeeh", "برېښنايي تسبېح"),
            l("Count by tap or swipe", "په تڼۍ یا د دانو په ښویولو شمېرل"),
            R.drawable.nav_adhkar,
        ) {
            go("tas")
        }
        entry(
            l("Hisn al-Muslim", "حصن المسلم"),
            l("Complete collection", "بشپړ کتاب"),
            R.drawable.nav_quran,
        ) {
            go("adhkar")
        }
        entry(
            l("Daily supplications", "ورځنۍ دعاګانې"),
            l("By time and occasion", "د وخت او حالت له مخې"),
            R.drawable.nav_adhkar,
        ) {
            go("occasions")
        }
        entry(
            l("Learn to pray", "د لمانځه زده کړه"),
            l("Hanafi prayer from preparation to salam", "له چمتووالي تر سلام پورې"),
            R.drawable.nav_prayer,
        ) {
            go("salah")
        }
        entry(
            l("How to make Wudu", "د اوداسه طریقه"),
            l("Illustrated Hanafi guide", "انځوریز حنفي لارښود"),
            R.drawable.ic_water,
        ) {
            go("wudu")
        }
        entry(
            l("Privacy & notices", "محرمیت او خبرتیاوې"),
            l("Data, sources and licenses", "معلومات، سرچینې او جوازونه"),
            R.drawable.ic_privacy,
        ) {
            go("legal")
        }
        entry(
            l("Morning & evening", "سهار او ماښام"),
            l("Hisn al-Muslim   ·   Chapter 27", "حصن المسلم · ۲۷م څپرکی"),
            R.drawable.ic_sun,
        ) {
            chapter = 27
            go("chapter")
        }
        entry(
            l("Islamic calendar", "هجري کلیز"),
            l(
                "Explore Hijri dates and adjust for local moon sighting.",
                "هجري نېټې وګورئ او د سیمه ییزې میاشت لیدنې له مخې یې برابرې کړئ.",
            ),
            R.drawable.ic_calendar,
        ) {
            go("calendar")
        }
        entry(
            l("About the developer", "د جوړوونکي پېژندنه"),
            l("Noman Momand · Why I built Al Noor", "نعمان مومند · ولې مې النور جوړ کړ؟"),
            R.drawable.ic_profile,
        ) {
            go("founder")
        }
        entry(
            l("Daily notifications & settings", "خبرتیاوې او تنظیمات"),
            l(
                "Daily ayah, recitation, adhkar and reading preferences",
                "ورځنی آیت، تلاوت، اذکار او د لوست تنظیمات",
            ),
            R.drawable.reminder,
        ) {
            go("settings")
        }
    }

    override fun onResume() {
        super.onResume()
        if (::catalog.isInitialized && route in listOf("home", "prayer", "settings", "calendar"))
            render()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 58 && route == "settings") render()
    }

    private fun savePosition() {
        prefs.edit().putInt("surah", surah).putInt("ayah", ayah).apply()
    }

    private fun dailyCard(s: Int, a: Int) {
        val chapter = catalog.surahs[s - 1]
        val v = chapter.verses[a - 1]
        val box = card()
        box.addView(
            label(l("AYAH OF THE DAY", "د نن ورځې آیت"), 12, muted).apply { letterSpacing = .12f }
        )
        box.addView(label(titleOf(chapter) + "   ·   $s:$a", 22, ink, true))
        rtl(box, v.arabic, prefs.getInt("size", 27))
        translation(box, v)
        box.addView(
            label(
                editionCredit(),
                12,
                muted,
            )
        )
        action(box, l("Read in context", "آیت په سورت کې ولولئ")) {
            surah = s
            ayah = a
            savePosition()
            go("reader")
        }
    }

    private fun index() {
        begin(
            l("Meanings", "د معناوو ژباړه"),
            l("Quran with translation", "قرآن له ژباړې سره"),
            l("Choose a surah or resume your reading", "سورت وټاکئ یا خپل لوست ته دوام ورکړئ"),
        )
        val field =
            EditText(this).apply {
                isSingleLine = true
                hint = l("Find by number or surah name", "د سورت نوم یا شمېره ولټوئ")
                setText(query)
            }
        val box = card()
        box.addView(field)
        entry(
            l("Resume ", "لوست ته دوام: ") + titleOf(catalog.surahs[surah - 1]),
            l("Continue at ayah ", "له دې آیته دوام: ") + ayah,
        ) {
            go("reader")
        }

        val list = LinearLayout(this).apply { orientation = 1 }
        body.addView(list)
        fun filter(value: String) {
            list.removeAllViews()
            val found =
                catalog.surahs.filter {
                    value.isBlank() ||
                        it.id.toString() == value ||
                        (it.name + " " + it.arabic + " " + it.meaning).contains(value, true)
                }
            if (found.isEmpty())
                list.addView(label(l("No matching surah", "سورت ونه موندل شو"), 16, muted))
            found.forEach { s ->
                action(list, "${s.id}   ${titleOf(s)}") {
                    surah = s.id
                    ayah = 1
                    savePosition()
                    go("reader")
                }
            }
        }
        filter(query)
        field.addTextChangedListener(
            object : android.text.TextWatcher {
                override fun afterTextChanged(s: android.text.Editable?) {
                    query = s.toString().trim()
                    filter(query)
                }

                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int,
                ) {}

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            }
        )
        body.isFocusableInTouchMode = true
        body.requestFocus()
    }

    private fun jump() {
        val s = catalog.surahs[surah - 1]
        val input =
            EditText(this).apply {
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
                hint = "1–" + s.verses.size
            }
        val dialog =
            AlertDialog.Builder(this)
                .setTitle(l("Go to ayah", "آیت ته لاړ شئ"))
                .setView(input)
                .setPositiveButton(l("Open", "پرانیستل"), null)
                .setNegativeButton(l("Cancel", "لغوه"), null)
                .create()
        dialog.setOnShowListener {
            dialog.getButton(-1).setOnClickListener {
                val n = input.text.toString().toIntOrNull()
                if (n == null || n !in 1..s.verses.size)
                    input.error = l("Enter 1–", "شمېره ولیکئ: ۱–") + s.verses.size
                else {
                    ayah = n
                    savePosition()
                    dialog.dismiss()
                    render()
                }
            }
        }
        dialog.show()
    }

    private fun reader() {
        prefs.edit().putString("lastReader", "reader").apply()
        val s = catalog.surahs[surah - 1]
        val end = minOf(ayah + 5, s.verses.size)
        begin(
            l("Surah ", "سورت ") + surah,
            titleOf(s),
            s.verses.size.toString() + l(" ayahs", " آیتونه"),
        )
        val controls = card()
        controls.addView(
            Switch(this).apply {
                text = t4("Show English meaning", "پښتو ژباړه ښودل", "نمایش ترجمه دری", "عرض الترجمة المختارة")
                minHeight = dp(48)
                isChecked = prefs.getBoolean("pashto", true)
                setOnCheckedChangeListener { _, v ->
                    prefs.edit().putBoolean("pashto", v).apply()
                    render()
                }
            }
        )
        action(controls, t4("Translation edition", "د ژباړې چاپ", "نسخه ترجمه", "نسخة الترجمة")) { translationMenu() }
        action(controls, l("Reading size", "د لیک اندازه")) { changeReadingSize() }
        action(controls, l("Ayahs $ayah–$end   ·   Jump", "آیتونه $ayah–$end · آیت ته تګ")) {
            jump()
        }
        for (i in ayah..end) {
            val v = s.verses[i - 1]
            val box = card()
            box.addView(label("$surah  /  $i", 12, muted))
            rtl(box, opening(Ref(surah, i), v.arabic), prefs.getInt("size", 27))
            if (prefs.getBoolean("pashto", true)) {
                translation(box, v)
            }
        }
        val flip = card()
        if (ayah > 1)
            action(flip, l("Previous ayahs", "مخکیني آیتونه")) {
                ayah = maxOf(1, ayah - 6)
                savePosition()
                render()
            }
        if (end < s.verses.size)
            action(flip, l("Next ayahs", "راتلونکي آیتونه")) {
                ayah = end + 1
                savePosition()
                render()
            }
        else if (surah < 114)
            action(flip, l("Next surah", "بل سورت")) {
                surah++
                ayah = 1
                savePosition()
                render()
            }
    }

    private fun adhkar() {
        begin(
            l("Supplications", "دعاګانې"),
            l("Hisn al-Muslim", "حصن المسلم"),
            l("Fortress of the Muslim   ·   Arabic supplications", "په عربي ژبه نبوي دعاګانې"),
        )
        val search =
            EditText(this).apply {
                hint = l("Search chapters, e.g. clothing or travel", "څپرکي ولټوئ، لکه جامې یا سفر")
                isSingleLine = true
            }
        card().addView(search)
        entry(
            l("Read the complete book", "بشپړ کتاب ولولئ"),
            l("Published English edition · all pages", "چاپ شوی پښتو کتاب · ټولې پاڼې"),
        ) {
            go("book")
        }
        entry(
            l("Daily supplications", "ورځنۍ دعاګانې"),
            l("Find a dua by occasion", "د وخت او حالت له مخې دعا ومومئ"),
        ) {
            go("occasions")
        }
        val rows =
            catalog.chapters.map { c ->
                entry(
                    chapterName(c),
                    l("Chapter ", "څپرکی ") +
                        c.id +
                        "   ·   " +
                        c.entries.size +
                        l(" entries", " دعاګانې"),
                ) {
                    chapter = c.id
                    go("chapter")
                }
                c to body.getChildAt(body.childCount - 1)
            }
        val empty = label(l("No matching chapters", "څپرکی ونه موندل شو"), 16, muted)
        body.addView(empty)
        empty.visibility = android.view.View.GONE
        search.addTextChangedListener(
            object : android.text.TextWatcher {
                override fun afterTextChanged(value: android.text.Editable?) {
                    val term = value.toString().trim()
                    var count = 0
                    rows.forEach { (c, row) ->
                        val show = chapterName(c).contains(term, true) || c.id.toString() == term
                        row.visibility =
                            if (show) android.view.View.VISIBLE else android.view.View.GONE
                        if (show) count++
                    }
                    empty.visibility =
                        if (count == 0) android.view.View.VISIBLE else android.view.View.GONE
                }

                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int,
                ) {}

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            }
        )
        body.isFocusableInTouchMode = true
        body.requestFocus()
    }

    private fun invocations() {
        val c = catalog.chapters.first { it.id == chapter }
        begin(
            l("Hisn al-Muslim   /   ", "حصن المسلم / ") + c.id,
            chapterName(c),
            l("Saʿīd ibn ʿAlī al-Qaḥṭānī", "سعید بن علي القحطاني"),
        )
        action(card(), l("Read this chapter in English", "دا څپرکی په پښتو ولولئ")) {
            bookChapter(chapter)
        }
        c.entries.forEachIndexed { index, r ->
            val box = card()
            box.addView(
                label(
                    l(
                        "Hisn al-Muslim   ·   Chapter $chapter.${index+1}   ·   Source ID ",
                        "حصن المسلم · څپرکی $chapter.${index+1} · د دعا شمېره ",
                    ) + r.id,
                    13,
                    muted,
                )
            )
            rtl(box, r.text, prefs.getInt("size", 27))
            val times = if (r.id == 83) 7 else r.repeats
            box.addView(label(l("Occasion: ", "مناسب وخت: ") + chapterName(c), 15))
            box.addView(
                label(
                    if (times > 1) l("Repeat $times times", "$times ځله یې ووایئ")
                    else
                        l(
                            "Read once; follow any additional directions in the entry.",
                            "یو ځل یې ولولئ؛ د دعا په متن کې نورې لارښوونې هم وګورئ.",
                        ),
                    15,
                )
            )
            val key = "counter/$chapter/$index"
            val day = LocalDate.now().toString() + "/"
            var count =
                prefs
                    .getString(key, "")
                    ?.takeIf { it.startsWith(day) }
                    ?.substringAfter('/')
                    ?.toIntOrNull() ?: 0
            val b = Button(this)
            box.addView(b)
            fun update() {
                b.text =
                    l("Count   $count   ·   Tap to add", "شمېر $count · د زیاتولو لپاره یې کېکاږئ")
            }
            b.isAllCaps = false
            update()
            b.setOnClickListener {
                count++
                prefs.edit().putString(key, day + count).apply()
                update()
            }
            action(box, l("Reset count", "شمېر له سره پیل کړئ")) {
                count = 0
                prefs.edit().remove(key).apply()
                update()
            }
        }
    }
}
