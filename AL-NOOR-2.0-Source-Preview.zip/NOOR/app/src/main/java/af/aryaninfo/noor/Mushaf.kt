package af.aryaninfo.noor

import android.app.AlertDialog
import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.text.*
import android.util.TypedValue
import android.util.Xml
import android.view.*
import android.widget.*
import org.xmlpull.v1.XmlPullParser

data class Ref(val s: Int, val a: Int) : Comparable<Ref> {
    override fun compareTo(other: Ref) = compareValuesBy(this, other, Ref::s, Ref::a)
}

class PageMap(context: Context) {
    val pages = mutableListOf<Ref>()
    val parts = mutableListOf<Ref>()

    init {
        context.assets.open("meta.xml").use {
            val x = Xml.newPullParser()
            x.setInput(it, "UTF-8")
            while (x.next() != XmlPullParser.END_DOCUMENT) if (
                x.eventType == XmlPullParser.START_TAG && x.name in listOf("juz", "page")
            ) {
                val r =
                    Ref(
                        x.getAttributeValue(null, "sura").toInt(),
                        x.getAttributeValue(null, "aya").toInt(),
                    )
                (if (x.name == "page") pages else parts).add(r)
            }
        }
        check(pages.size == 604 && parts.size == 30)
    }

    fun page(ref: Ref) = pages.indexOfLast { it <= ref } + 1

    fun juz(ref: Ref) = parts.indexOfLast { it <= ref } + 1

    fun refs(page: Int, c: Catalog): List<Ref> {
        val first = pages[page - 1]
        val stop = pages.getOrNull(page) ?: Ref(115, 1)
        return buildList {
            var r = first
            while (r < stop) {
                add(r)
                r = if (r.a == c.surahs[r.s - 1].verses.size) Ref(r.s + 1, 1) else Ref(r.s, r.a + 1)
            }
        }
    }
}

fun MainActivity.changeReadingSize() {
    val sizes = listOf(22, 27, 32, 38)
    AlertDialog.Builder(this)
        .setTitle(l("Reading text size", "د لوست د لیک اندازه"))
        .setSingleChoiceItems(
            sizes.map { "$it sp" }.toTypedArray(),
            sizes.indexOf(prefs.getInt("size", 27)),
        ) { d, i ->
            prefs.edit().putInt("size", sizes[i]).apply()
            d.dismiss()
            render()
        }
        .show()
}

private fun MainActivity.openPage(n: Int) {
    prefs.edit().putInt("mushafPage", n.coerceIn(1, 604)).apply()
    go("mushaf")
}

private fun MainActivity.jumpPage() {
    val f =
        EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            hint = "1–604"
        }
    val d =
        AlertDialog.Builder(this)
            .setTitle(l("Go to page", "پاڼې ته تګ"))
            .setView(f)
            .setPositiveButton(l("Open", "پرانیستل"), null)
            .setNegativeButton(l("Cancel", "لغوه"), null)
            .create()
    d.setOnShowListener {
        d.getButton(-1).setOnClickListener {
            val n = f.text.toString().toIntOrNull()
            if (n == null || n !in 1..604)
                f.error = l("Enter a page from 1 to 604", "له ۱ تر ۶۰۴ پورې شمېره ولیکئ")
            else {
                d.dismiss()
                openPage(n)
            }
        }
    }
    d.show()
}

fun MainActivity.quranHub() {
    begin(
        l("Reading", "تلاوت"),
        l("Quran", "قرآن"),
        l("Choose how you would like to read", "د لوست بڼه وټاکئ"),
    )
    entry(
        l("Resume recitation", "تلاوت ته دوام"),
        l("Page ", "پاڼه ") + prefs.getInt("mushafPage", 1) + l(" of 604", " له ۶۰۴ څخه"),
    ) {
        go("mushaf")
    }
    entry(
        l("Quran with translation", "قرآن له ژباړې سره"),
        l("Arabic text and English meaning", "عربي متن او پښتو ژباړه"),
    ) {
        prefs.edit().putBoolean("pashto", true).apply()
        go("translationIndex")
    }
    entry(l("Juz index", "د سپارو لړلیک"), l("30 parts", "۳۰ سپارې")) { go("juz") }
    entry(l("Surah index", "د سورتونو لړلیک"), l("114 surahs", "۱۱۴ سورتونه")) { go("surahIndex") }
    entry(l("Go to page", "پاڼې ته تګ"), l("Enter a page number", "د پاڼې شمېره ولیکئ")) {
        jumpPage()
    }
    entry(l("Bookmarks", "نښه شوې پاڼې"), l("Saved recitation pages", "د تلاوت خوندي شوې پاڼې")) {
        go("bookmarks")
    }
}

fun MainActivity.mushafIndex(juz: Boolean) {
    val m = pageMap
    begin(
        if (juz) l("Parts", "سپارې") else l("Chapters", "سورتونه"),
        if (juz) l("Juz index", "د سپارو لړلیک") else l("Surah index", "د سورتونو لړلیک"),
        l("Select a starting page", "د پیل پاڼه وټاکئ"),
    )
    val refs = if (juz) m.parts else catalog.surahs.map { Ref(it.id, 1) }
    refs.forEachIndexed { i, r ->
        val s = catalog.surahs[r.s - 1]
        val page = m.page(r)
        entry(
            if (juz) l("Juz ${i+1}", "سپاره ${i+1}") else "${s.id}. ${titleOf(s)}",
            l(
                "${s.arabic}   ·   ${r.s}:${r.a}   ·   Page $page",
                "${s.arabic} · ${r.s}:${r.a} · پاڼه $page",
            ),
        ) {
            openPage(page)
        }
    }
}

fun MainActivity.bookmarkList() {
    begin(
        l("Saved", "نښې"),
        l("Bookmarks", "نښه شوې پاڼې"),
        l("Saved recitation pages", "د تلاوت خوندي شوې پاڼې"),
    )
    val m = pageMap
    val saved =
        prefs
            .getStringSet("pageMarks", emptySet())
            .orEmpty()
            .mapNotNull { it.toIntOrNull() }
            .sorted()
    if (saved.isEmpty())
        card()
            .addView(
                label(
                    l(
                        "Tap Bookmark at the bottom of a recitation page.",
                        "د تلاوت د پاڼې لاندې د نښې تڼۍ کېکاږئ.",
                    ),
                    17,
                )
            )
    saved.forEach { n ->
        entry(l("Page $n", "پاڼه $n"), titleOf(catalog.surahs[m.pages[n - 1].s - 1])) {
            openPage(n)
        }
    }
}

private data class Paper(val name: String, val bg: Int, val fg: Int, val rule: Int)

private val papers =
    listOf(
        Paper("Light", 0xfffffcf2.toInt(), 0xff231f18.toInt(), 0xffa69b82.toInt()),
        Paper("Warm amber", 0xffffdda2.toInt(), 0xff392918.toInt(), 0xffa17d45.toInt()),
        Paper("Dark", 0xff192421.toInt(), 0xfff0e7d5.toInt(), 0xff697c70.toInt()),
        Paper("Midnight OLED", 0xff080808.toInt(), 0xfff5f5f5.toInt(), 0xff454545.toInt()),
        Paper("Lunar Gold", 0xff392a1f.toInt(), 0xffffe9c6.toInt(), 0xff97764c.toInt()),
        Paper("Celestial Blue", 0xff10192d.toInt(), 0xffe1e8ff.toInt(), 0xff52698c.toInt()),
    )

private fun digits(n: Int) = n.toString().map { "٠١٢٣٤٥٦٧٨٩"[it - '0'] }.joinToString("")

/** The text layout itself supplies the baselines, keeping each rule below its Arabic line. */
private class RuledText(context: Context, val rule: Int) : TextView(context) {
    private val p =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = rule
            strokeWidth = resources.displayMetrics.density * .55f
        }

    override fun onDraw(canvas: Canvas) {
        val layout = layout
        if (layout != null)
            for (i in 0 until layout.lineCount) {
                val y = (totalPaddingTop + layout.getLineBottom(i)).toFloat()
                canvas.drawLine(paddingLeft.toFloat(), y, (width - paddingRight).toFloat(), y, p)
            }
        super.onDraw(canvas)
    }
}

/** Fit using Android's final Arabic glyph measurements before the child is laid out. */
private class PageViewport(context: Context, private val zoom: Int) : ScrollView(context) {
    var flip: (Int) -> Unit = {}
    private var downX = 0f
    private var downY = 0f

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked == MotionEvent.ACTION_DOWN) {
            downX = event.x
            downY = event.y
        }
        if (event.actionMasked == MotionEvent.ACTION_UP) {
            val dx = event.x - downX
            if (
                kotlin.math.abs(dx) > resources.displayMetrics.density * 50 &&
                    kotlin.math.abs(dx) > 1.5 * kotlin.math.abs(event.y - downY)
            ) {
                val cancel = MotionEvent.obtain(event)
                cancel.action = MotionEvent.ACTION_CANCEL
                super.dispatchTouchEvent(cancel)
                cancel.recycle()
                flip(if (dx > 0) 1 else -1)
                return true
            }
        }
        return super.dispatchTouchEvent(event)
    }

    private var lastWidth = -1
    private var lastHeight = -1

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec) - paddingLeft - paddingRight
        val h = MeasureSpec.getSize(heightMeasureSpec) - paddingTop - paddingBottom
        val page = getChildAt(0) as? TextView
        if (page != null && w > 0 && h > 0 && (w != lastWidth || h != lastHeight)) {
            lastWidth = w
            lastHeight = h
            var lo = 1f
            var hi = 50 * resources.displayMetrics.density
            val width = MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY)
            val unlimited = MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
            repeat(13) {
                val mid = (lo + hi) / 2
                page.setTextSize(TypedValue.COMPLEX_UNIT_PX, mid)
                page.forceLayout()
                page.measure(width, unlimited)
                if (page.measuredHeight <= h - 2) lo = mid else hi = mid
            }
            page.setTextSize(TypedValue.COMPLEX_UNIT_PX, lo * zoom / 100)
            page.forceLayout()
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
    }
}

fun MainActivity.mushafReader() {
    prefs.edit().putString("lastReader", "mushaf").apply()
    val m = pageMap
    val n = prefs.getInt("mushafPage", 1).coerceIn(1, 604)
    val refs = m.refs(n, catalog)
    val first = refs.first()
    val paper = papers[prefs.getInt("pageTone", 0).coerceIn(0, papers.lastIndex)]
    begin(l("Reading", "تلاوت"), l("Recitation", "تلاوت"), "")
    root.removeView(scroll)
    root.setBackgroundColor(paper.bg)
    @Suppress("DEPRECATION")
    if (prefs.getInt("pageTone",0) >= 2)
        window.decorView.systemUiVisibility =
            window.decorView.systemUiVisibility and
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv() and
                View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
    fun bar(): LinearLayout =
        LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setBackgroundColor(paper.bg)
            root.addView(this)
        }
    fun item(row: LinearLayout, text: String, fn: () -> Unit) {
        row.addView(
            label(text, 15, paper.fg).apply {
                gravity = Gravity.CENTER
                minHeight = dp(46)
                isFocusable = true
                setOnClickListener { fn() }
            },
            LinearLayout.LayoutParams(0, -2, 1f),
        )
    }
    val top = bar()
    item(top, l("‹ Back", "شاته")) { if (trailEmpty()) go("quran") else onBackPressed() }
    item(top, l("Index", "لړلیک")) { go("quran") }
    item(top, l("Page $n", "پاڼه $n")) { jumpPage() }
    fun turn(step: Int) {
        if (n + step !in 1..604) return
        if (prefs.getBoolean("pageSound", true)) pageRustle()
        openPage(n + step)
    }
    val head =
        label(
            l(
                "Juz ${m.juz(first)}     ◆     ${catalog.surahs[first.s-1].arabic}     ◆     ${digits(n)}",
                "سپاره ${m.juz(first)}     ◆     ${catalog.surahs[first.s-1].arabic}     ◆     ${digits(n)}",
            ),
            17,
            paper.fg,
            true,
        )
    head.gravity = Gravity.CENTER
    root.addView(head)
    val surface =
        FrameLayout(this).apply {
            background =
                GradientDrawable().apply {
                    setColor(paper.bg)
                    setStroke(dp(2), paper.rule)
                }
            setPadding(dp(5), dp(5), dp(5), dp(5))
        }
    root.addView(
        surface,
        LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(dp(7), dp(5), dp(7), dp(3)) },
    )
    val area =
        PageViewport(this, prefs.getInt("pageZoom", 100)).apply {
            background =
                GradientDrawable().apply {
                    setColor(paper.bg)
                    setStroke(dp(1), paper.rule)
                }
            setPadding(dp(7), dp(5), dp(7), dp(6))
        }
    surface.addView(area)
    val text =
        RuledText(this, paper.rule).apply {
            typeface = readingTypeface
            setTextColor(paper.fg)
            textDirection = View.TEXT_DIRECTION_RTL
            gravity = Gravity.RIGHT
            includeFontPadding = false
            justificationMode = android.text.Layout.JUSTIFICATION_MODE_INTER_WORD
            breakStrategy = android.text.Layout.BREAK_STRATEGY_SIMPLE
            text = buildString {
                refs.forEachIndexed { i, r ->
                    if (i > 0 && r.a == 1) append("\n﴿ " + catalog.surahs[r.s - 1].arabic + " ﴾\n")
                    append(opening(r, catalog.surahs[r.s - 1].verses[r.a - 1].arabic))
                    append(" ﴿" + digits(r.a) + "﴾ ")
                }
            }
            setTextIsSelectable(true)
        }
    area.addView(text)
    area.flip = { delta -> turn(delta) }
    val controls = bar()
    item(controls, l("Size −", "کوچنی −")) {
        prefs
            .edit()
            .putInt("pageZoom", (prefs.getInt("pageZoom", 100) - 10).coerceAtLeast(70))
            .apply()
        render()
    }
    item(controls, l("Size +", "لوی +")) {
        prefs
            .edit()
            .putInt("pageZoom", (prefs.getInt("pageZoom", 100) + 10).coerceAtMost(170))
            .apply()
        render()
    }
    item(controls, l("Colour", "رنګ")) {
        prefs.edit().putInt("pageTone", (prefs.getInt("pageTone", 0) + 1) % papers.size).apply()
        render()
    }
    val marks = prefs.getStringSet("pageMarks", emptySet()).orEmpty().toMutableSet()
    item(controls, if ("$n" in marks) l("Unmark", "نښه لرې") else l("Bookmark", "نښه")) {
        if (!marks.add("$n")) marks.remove("$n")
        prefs.edit().putStringSet("pageMarks", marks).apply()
        render()
    }
    val shortcuts = bar()
    item(shortcuts, l("Translation", "ژباړه")) { openTranslation(first.s, first.a) }
    item(
        shortcuts,
        if (prefs.getBoolean("pageSound", true)) l("Sound on", "غږ فعال")
        else l("Sound off", "غږ بند"),
    ) {
        prefs.edit().putBoolean("pageSound", !prefs.getBoolean("pageSound", true)).apply()
        render()
    }
    val bottom = bar()
    item(bottom, l("Previous", "مخکینۍ")) { turn(-1) }
    item(bottom, "$n / 604") { jumpPage() }
    item(bottom, l("Next", "بله")) { turn(1) }
}
