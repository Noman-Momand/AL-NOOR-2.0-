"""Verify the shipped editions and every surah/ayah join, without internet access."""
from hashlib import sha256
import json
from pathlib import Path
import sqlite3
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "app/src/main/assets"

def verify():
    for line in (ROOT / "tools/content.sha256").read_text().splitlines():
        digest, name = line.split()
        assert sha256((ASSETS / name).read_bytes()).hexdigest() == digest, name
    metadata = ET.parse(ASSETS / "meta.xml").findall("./suras/sura")
    keys = [(int(s.get("index")), i) for s in metadata for i in range(1, int(s.get("ayas")) + 1)]
    assert len(metadata) == 114 and len(keys) == 6236
    lines = [v.split("|", 2) for v in (ASSETS / "quran.txt").read_text().splitlines() if v[:1].isdigit()]
    assert [(int(s), int(a)) for s, a, text in lines] == keys and all(t.strip() for _, _, t in lines)
    editions = ["pashto_rwwad.sqlite", "english_saheeh.sqlite"]
    if (ASSETS / "dari_badkhashani.sqlite").exists():
        assert (ASSETS / "dari-publisher-notice.txt").exists()
        assert (ASSETS / "darimeta.json").exists()
        editions.append("dari_badkhashani.sqlite")
    for name in editions:
        with sqlite3.connect(f"file:{ASSETS / name}?mode=ro", uri=True) as db:
            rows = db.execute("SELECT sura, aya, translation, footnotes FROM translations ORDER BY sura,aya").fetchall()
        assert [(s, a) for s, a, _, _ in rows] == keys
        assert all(t and t.strip() for _, _, t, _ in rows)
        print(f"{name}: {len(rows)} verse mappings and {sum(bool(n) for *_, n in rows)} footnotes")
    for lang, pages in (("en",159), ("ps",302)):
        index = list(map(int,(ASSETS / f"hisn-pages-{lang}.txt").read_text().splitlines()))
        assert len(index) == 132 and sorted(index)==index and 1 <= index[0] <= index[-1] <= pages
    assert len((ASSETS / "chapters-ps.txt").read_text().splitlines()) == 132
    items = json.loads((ASSETS / "hisn.json").read_text())
    assert [c["id"] for c in items] == list(range(1, 133))
    entries = [r for c in items for r in c["entries"]]
    assert len(entries) == 267 and all(r["arabic"].strip() for r in entries)
    assert sorted(r["id"] for r in entries) == list(range(1,268))
    print("Verified 114 surahs, both Quran translations, 132 chapters, both book indexes and 267 distinct Hisn entries.")
if __name__ == "__main__":
    verify()
