#!/usr/bin/env python3
"""Import publisher's Dari edition verbatim after permission and edition review.
No third-party fallback; failures leave existing assets untouched.
"""
import argparse, hashlib, json, sqlite3, tempfile, time, urllib.request
from pathlib import Path
from xml.etree import ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
A=ROOT/'app/src/main/assets'
KEY='dari_badkhashani'
VERSION='1.0.0'
BASE='https://quranenc.com/api/v1/translation/sura/'

def main():
    p=argparse.ArgumentParser(); p.add_argument('--publisher-confirmed',action='store_true',help='Confirm edition, access and republication conditions including transcript and publisher credit.');p.add_argument('--publisher-notice',type=Path,required=True,help='Original edition publisher/transcript notice, saved unmodified.'); args=p.parse_args()
    if not args.publisher_confirmed: p.error('Review publisher rights and access first.')
    notice=args.publisher_notice.read_bytes()
    if not notice.strip(): p.error('Publisher notice cannot be empty.')
    metadata=ET.parse(A/'meta.xml').findall('./suras/sura')
    expected=[(int(s.get('index')),i) for s in metadata for i in range(1,int(s.get('ayas'))+1)]
    assert len(expected)==6236
    rows=[]; raw=[]
    for s in range(1,115):
        req=urllib.request.Request(f'{BASE}{KEY}/{s}',headers={'User-Agent':'AL-NOOR-content-import/2.0 (publisher edition validation)'})
        with urllib.request.urlopen(req,timeout=45) as r: obj=json.load(r)
        items=obj['result']; raw.append(obj)
        for x in items:
            assert isinstance(x['translation'],str) and x['translation'].strip()
            assert x.get('footnotes') is None or isinstance(x.get('footnotes'),str)
            rows.append((int(x['sura']),int(x['aya']),x['translation'],x.get('footnotes') or ''))
        time.sleep(.2)
    assert [(s,a) for s,a,_,_ in rows]==expected, 'Invalid or incomplete edition'
    with tempfile.TemporaryDirectory(dir=A) as td:
        t=Path(td); db=t/(KEY+'.sqlite')
        with sqlite3.connect(db) as c:
            c.execute('CREATE TABLE translations(sura INTEGER, aya INTEGER, translation TEXT NOT NULL, footnotes TEXT NOT NULL, PRIMARY KEY(sura,aya))')
            c.executemany('INSERT INTO translations VALUES(?,?,?,?)',rows)
            assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
        (t/'darimeta.json').write_text(json.dumps({'key':KEY,'version':VERSION,'translator':'Muhammad Anwar Badakhshani','source':'https://quranenc.com/en/browse/dari_badkhashani','raw_responses':raw},ensure_ascii=False),encoding='utf-8')
        (t/'dari-publisher-notice.txt').write_bytes(notice)
        files=list(t.iterdir()); hashes=ROOT/'tools/content.sha256'; old=hashes.read_text().splitlines(); names={f.name for f in files}
        lines=[line for line in old if line.split()[-1] not in names]
        for f in files:
            lines.append(f'{hashlib.sha256(f.read_bytes()).hexdigest()}  {f.name}');f.replace(A/f.name)
        hashes.write_text('\n'.join(lines)+'\n')
    print('Imported 6,236 Dari verse mappings. Review content and run verify_content.py before release.')
if __name__=='__main__':main()
