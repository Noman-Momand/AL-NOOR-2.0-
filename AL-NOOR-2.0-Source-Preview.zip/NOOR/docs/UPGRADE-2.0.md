# AL NOOR 2.0 source preview

This is an incremental modification of the recovered NOOR 0.3.0 Android project, not a replacement application. It keeps the original application ID, debug suffix, Gradle wrapper, offline assets, bookmarks, settings, and prior features.

## Added to this source preview
- Six app palettes (Lunar Gold default, Midnight OLED, Pearl White, Royal Emerald, Classic Manuscript, Celestial Blue), system light/dark option, and six independent Mushaf paper styles.
- Live local-time moon clock with approximate lunar phase illustration, screen brightness and screen-awake options; circular, minimal and timeline prayer summaries computed with the existing Hanafi method and selected city. Existing AlAdhan cached timetable remains separate: summaries are labeled as offline calculations.
- Ramadan daily Fajr/Maghrib planner, countdown and self-recorded fast checkbox; Quran search of original text and selected installed meaning, private local journal and daily ayah practice target.
- Android home screen clock and daily-ayah reference widget. Launcher refreshes the reference periodically; it is not a real-time prayer countdown widget.
- Four-language selector, RTL direction for Pashto/Dari/Arabic, core interface translations in UiWords.kt and separately selectable translation language. Arabic mode shows the original Arabic Quran, not a generated Arabic translation.
- Dari translation database support, source attribution, publisher link and guarded import utility. No unverified Dari verse is included.

## Dari edition: important
QuranEnc lists Muhammad Anwar Badakhshani's Dari translation, edition 1.0.0 (2021-02-16): https://quranenc.com/en/browse/dari_badkhashani
The publisher lists general republication conditions, including unchanged wording, attribution, version and transcript information. This specific edition's export availability is unclear: the catalog does not show a download button and the API could not be tested here. Obtain confirmation and the original publisher/transcript notice before bundling the text. The original edition is available to browse via the official website. No substitute translation has been generated.

If the publisher confirms API access and republication, run from the project root:

```
python3 tools/import_dari.py --publisher-confirmed --publisher-notice /path/to/original-notice.txt
python3 tools/verify_content.py
```

The importer fetches the documented API directly, keeps every translation and footnote, demands all 6,236 canonical surah/ayah keys in order, stores the publisher notice and original response data, and records hashes. If the endpoint is unavailable, it fails rather than inventing missing data. Confirm the actual edition and current version with the publisher; the version is pinned to the listing above. The verifier validates structure and byte integrity, not theological correctness.

## Still pending before public release
- Complete human-reviewed Dari and Arabic localization (legacy strings not mapped in UiWords.kt still show English), date formatting, complete Arabic and Dari published Hisn book editions, review of religious instructional translations.
- Full offline Dari text pending publisher access and import; no claim of a complete Dari translation in this ZIP.
- Additional proposed features not implemented: per-prayer Azan alarms/adjustments, detailed fasting calendar and statistics, advanced memorization scheduling, Qibla upgrades, full prayer widgets, full-screen landscape-specific layout, cloud backup, 99 names, zakat, Hajj/Umrah, wallpaper/greeting tools. Existing Tasbeeh and Qibla features remain. Journal is local private app storage, not separately encrypted.
- Scholarly review of inherited Hisn references and Hanafi guide, publisher permissions and real-device testing of all four interfaces and six palettes; see CONTENT.md.
- APK compilation and Android unit tests could not run in this environment (no installed Android SDK or Gradle distribution; Gradle server DNS resolution fails). Source changes are uncompiled and should be treated as a development preview, not a tested release.

## Build
Open the NOOR folder containing settings.gradle.kts in Android Studio, use JDK 17 and Android SDK 35. Or push the extracted folder contents to a GitHub repository root and run the existing Actions workflow, which verifies offline content and runs unit tests before building the debug APK. Do not publish until the pending religious content and language review is complete.
