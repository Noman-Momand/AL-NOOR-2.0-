# Al Noor 0.3.0 | Project structure

Open the folder containing settings.gradle.kts in Android Studio.

## Where to make a change

| Change | Start here | What to preserve |
|---|---|---|
| Today screen, navigation, reader, and chapter counters | MainActivity.kt | Surah and ayah numbering begins at one. Store personal state separately from edition assets. |
| Palette, Islamic geometric header, arch artwork, cards and Arabic text spacing | Design.kt, res/values/styles.xml, res/drawable/ | Reader text scaling, RTL alignment, contrast and system insets. |
| Quran or translation edition | Catalog.kt, assets/, tools/content.sha256, docs/CONTENT.md | Original strings and footnotes, edition credit, publisher notices, all 6,236 joins and cache version. |
| Selected daily verses, reminder times, notification text  | Companion.kt | Per-reminder alarm identities, actual delivered verse reference and independent user choices. |
| Hanafi learning text | Worship.kt | Prayer positions, source references, attribution and teacher review process. |
| Afghan city presets, calculation methods or compass | Prayer.kt | City date and IANA zone, true-north declination correction, visible manual bearing. |
| Hijri month grid or sighting adjustment | Calendar.kt | Date selection, day-of-month alignment and adjustment on both calendar and Today. |
| APK configuration | app/build.gradle.kts, AndroidManifest.xml | Native Kotlin module, offline reading and optional online timetable refresh, minimum API 26. |
| CI or regression checks | .github/workflows/android.yml, OfflineTest.kt, tools/verify_content.py | Run checks before uploading the CI debug APK. |


Language.kt selects the UI language and translation. Book.kt displays and indexes the full published editions. Tasbeeh.kt owns animated counting, the local totals and portable document backup. Mushaf.kt lays out and turns Quran pages. Timetable.kt validates optional online timings before caching them in SQLite.

## Files in the Android project

- `.github/workflows/android.yml`
- `.gitignore`
- `README.md`
- `app/build.gradle.kts`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/assets/ADHAN-LICENSE.txt`
- `app/src/main/assets/OFL.txt`
- `app/src/main/assets/ScheherazadeNew-Regular.ttf`
- `app/src/main/assets/chapters-ps.txt`
- `app/src/main/assets/credits.txt`
- `app/src/main/assets/english_saheeh.sqlite`
- `app/src/main/assets/enmeta.json`
- `app/src/main/assets/hanafi.json`
- `app/src/main/assets/hisn-en.pdf`
- `app/src/main/assets/hisn-pages-en.txt`
- `app/src/main/assets/hisn-pages-ps.txt`
- `app/src/main/assets/hisn-ps.pdf`
- `app/src/main/assets/hisn.json`
- `app/src/main/assets/meta.xml`
- `app/src/main/assets/noman-momand.jpg`
- `app/src/main/assets/pashto_rwwad.sqlite`
- `app/src/main/assets/psmeta.json`
- `app/src/main/assets/quran.txt`
- `app/src/main/assets/wudu-arms.webp`
- `app/src/main/assets/wudu-face.webp`
- `app/src/main/assets/wudu-feet.webp`
- `app/src/main/assets/wudu-hands.webp`
- `app/src/main/assets/wudu-head.webp`
- `app/src/main/assets/wudu-rinse.webp`
- `app/src/main/java/af/aryaninfo/noor/Book.kt`
- `app/src/main/java/af/aryaninfo/noor/Calendar.kt`
- `app/src/main/java/af/aryaninfo/noor/Catalog.kt`
- `app/src/main/java/af/aryaninfo/noor/Companion.kt`
- `app/src/main/java/af/aryaninfo/noor/Design.kt`
- `app/src/main/java/af/aryaninfo/noor/Language.kt`
- `app/src/main/java/af/aryaninfo/noor/MainActivity.kt`
- `app/src/main/java/af/aryaninfo/noor/Mushaf.kt`
- `app/src/main/java/af/aryaninfo/noor/Prayer.kt`
- `app/src/main/java/af/aryaninfo/noor/Tasbeeh.kt`
- `app/src/main/java/af/aryaninfo/noor/Timetable.kt`
- `app/src/main/java/af/aryaninfo/noor/Worship.kt`
- `app/src/main/res/drawable/ic_calendar.xml`
- `app/src/main/res/drawable/ic_privacy.xml`
- `app/src/main/res/drawable/ic_profile.xml`
- `app/src/main/res/drawable/ic_sun.xml`
- `app/src/main/res/drawable/ic_water.xml`
- `app/src/main/res/drawable/nav_adhkar.xml`
- `app/src/main/res/drawable/nav_prayer.xml`
- `app/src/main/res/drawable/nav_quran.xml`
- `app/src/main/res/drawable/nav_today.xml`
- `app/src/main/res/drawable/noor.xml`
- `app/src/main/res/drawable/reminder.xml`
- `app/src/main/res/raw/page_turn.wav`
- `app/src/main/res/values-ps/strings.xml`
- `app/src/main/res/values/strings.xml`
- `app/src/main/res/values/styles.xml`
- `app/src/test/java/af/aryaninfo/noor/OfflineTest.kt`
- `app/src/test/java/af/aryaninfo/noor/ReaderUpdateTest.kt`
- `app/src/test/resources/aladhan-kabul.json`
- `build.gradle.kts`
- `docs/CONTENT.md`
- `docs/DEVELOPMENT.md`
- `docs/STRUCTURE.md`
- `gradle.properties`
- `gradle/wrapper/gradle-wrapper.jar`
- `gradle/wrapper/gradle-wrapper.properties`
- `gradlew`
- `gradlew.bat`
- `settings.gradle.kts`
- `tools/content.sha256`
- `tools/verify_content.py`
