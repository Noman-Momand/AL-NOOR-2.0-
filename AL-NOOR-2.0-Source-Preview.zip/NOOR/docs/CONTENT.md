# Content register

| Asset | Edition and origin | Use in NOOR |
|---|---|---|
| quran.txt | Tanzil Uthmani 1.1, numbered text | Original UTF-8 file with publisher notice intact. Verse strings are displayed in source order. Opening basmalahs follow the source, with no added basmalah at the start of surah 9. |
| meta.xml | Tanzil metadata 1.0 | Source spellings, surah titles, verse counts and names. |
| pashto_rwwad.sqlite and psmeta.json | QuranEnc, Pashto Translation – Rowwad Translation Center, 1.0.1 | Original SQLite artifact and publisher metadata. Join by surah and ayah. Display every supplied footnote after its verse. |
| hisn.json | HisnMuslim.com English chapter index and Arabic_TEXT fields, Saʿīd al-Qaḥṭānī | 132 chapter labels and 267 Arabic entries. “Morning and evening” is chapter 27. The full book translations open at the corresponding chapter in either published PDF. |
| hanafi.json | Original educational summaries | Bibliography on each section. The guide introduces ordinary wudu and individual prayer. |
| Prayer calculations | Batoul Apps Adhan Java 1.2.1 | Derived from coordinates, date and method. The app identifies Hanafi Asr and the chosen method. |

**Publisher links**

- [Tanzil downloads and terms](https://tanzil.net/download/), [metadata](https://tanzil.net/res/text/metadata/quran-data.xml) and [updates](https://tanzil.net/updates/).
- [QuranEnc translation and republication terms](https://quranenc.com/en/browse/pashto_rwwad), [publisher metadata](https://quranenc.com/api/v1/translations/list/ps/) and [original archive](https://quranenc.com/downloads/sqlite/pashto_rwwad.zip).
- [Hisn source index](https://www.hisnmuslim.com/api/en/husn_en.json). Every chapter in the JSON retains its source URL. Cite the compilation item by chapter and entry ID. Chapter 126 has a malformed JSON title in the feed. The import reads the intact entry array. Chapter 132 uses the field Text for Arabic. Both are handled without editing the Arabic.
- [Adhan Java](https://github.com/batoulapps/adhan-java), [wudu](https://seekersguidance.org/answers/hanafi-fiqh/do-i-need-to-wash-my-mouth-and-wipe-my-ears-for-a-valid-wudu/), [sittings and recitation](https://seekersguidance.org/answers/hanafi-fiqh/how-much-recitation-is-required-for-a-valid-prayer/), [Witr](https://seekersguidance.org/answers/hanafi-fiqh/details-regarding-witr-confirmed-sunna-and-non-confirmed-sunna-prayers/).

**Updating an edition**

Keep all originals and attribution. Tanzil permits verbatim distribution with attribution, a link and its notice. QuranEnc requires unaltered text, publisher/source, version and transcript information, reporting translation observations to the publisher, keeping the edition current and avoiding inappropriate advertising. Record each publisher's version and any correction before replacing files. Confirm the current publisher terms when distributing a new edition. This project includes no ads.

For a public store release, obtain explicit confirmation of reuse terms for the Hisn digital compilation and metadata. Its public feed supplies provenance, but we did not verify a blanket republication license. Have a hadith editor resolve entry-level source references and grades where the feed omits them, and have a Hanafi teacher review the guide. A count of matching records and a file hash establish integrity, not independent scholarly review.

Repeat counts in the upstream feed sometimes differ from the prose inside an entry. The app offers an open tap counter and preserves the wording. Counters reset per device-local day. It does not assign a hadith grade or create new supplications.

## Reading edition additions
Tanzil meta.xml supplies the canonical page starts for this 604-page edition and all 30 Juz starts. The developer portrait was supplied by Noman Momand. His first-person story was adapted from his supplied text. Six AI-generated wudu illustrations accompany written instructions. The selected prayer supplications are read by their chapter and item IDs from the existing Hisn data. The app cites these references alongside the Arabic. The educational guide still awaits scholarly review.

Prayer timetable provider: [AlAdhan timing API](https://aladhan.com/prayer-times-api). The online endpoint uses Hanafi school 1 and methods 1 (Karachi), 3 (Muslim World League) or 4 (Umm al-Qura). Only validated daily times enter the cache.

## Bilingual edition register
- English Quran meanings and notes are copied verbatim from the [Noor International Center edition on QuranEnc](https://quranenc.com/en/browse/english_saheeh), publisher version 1.1.2.
- Both complete editions of Hisn are included as published. [English PDF](https://d1.islamhouse.com/data/en/ih_books/single/risala_en_hisnulmuslim.pdf) and [Pashto PDF](https://d1.islamhouse.com/data/ps/ih_books/single/ps_hisn_almuslim.pdf). The Pashto chapter headings in the search index are interface translations. The PDFs supply the published wording and references.
- The upstream digital index duplicated item 198, omitting item 197. Chapter 86 now contains [item 197](https://sunnah.com/hisn:197). The verifier requires every ID from 1 through 267 exactly once. Entry 83 uses the seven repetitions in its own wording. Publishers and a qualified editor should review distribution permissions, repetitions and source gradings before public release.
