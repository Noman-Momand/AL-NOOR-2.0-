# NOOR | Development plan and application architecture
**Aryan Info-Tech · Native Android / Kotlin · 0.3.0**

## Product and first launch
Today offers separate entrances to **Recite the Quran** and **Quran with translation**, with an English or Pashto interface. Recitation resumes by page; the translated reader resumes by surah and ayah. Both work immediately offline. Daily supplications, the complete Hisn collection, illustrated Wudu, Salah, the daily verse and the founder story are accessible from Today.

## Feature contracts
| Feature | Implementation | Acceptance check |
|---|---|---|
| Recitation | Continuous Arabic with inline ayah numbers in a ruled frame. The default size fits a complete page. Page themes and zoom are independent of translation preferences. | Verify pages 1, 2 and 604 and a multi-surah page in both orientations. Check zoom, resume, all indexes and bookmarks. |
| Quran with translation | Native right-to-left text blocks, six ayahs per segment, surah search, direct ayah jump, persistent translation toggle and four Arabic sizes | Open 1:1, 2:255, 9:1 and 114:6 offline. Confirm opening basmalahs against the text, verse alignment, and translation state after restarting. |
| Meanings | Complete Rowwad Pashto 1.0.1 and Noor International English 1.1.2 | Match all 6,236 references and original footnotes in each publisher database. Switch language on the same verse. |
| Hisn and daily adhkar | 132 chapters, 267 Arabic entries, a dedicated morning/evening shortcut, persistent daily tap counters | Enter chapter 27, increment two counters separately, reopen, reset one, repeat on the next civil date. |
| Daily ayah | 31 selected references rotate deterministically by device-local civil date. Full Arabic, the selected meaning and available notes come from the Quran reader's data | Check consecutive dates, the end of the cycle, and that the ayah notification opens the exact reference delivered. |
| Reminders | Separate local wall-clock choices for ayah, recitation and adhkar, each with its own notification channel. All start disabled | Grant or deny notifications, schedule two for the same minute, confirm separate delivery and tap destinations. Change time zone, reboot and disable each independently. |
| Digital Tasbeeh | One animated counter per Arabic phrase, button and swipe-bead modes, personal targets and a user-owned backup | Increment both ways, change phrases, restore a saved document after reinstall and compare all totals. |
| Prayer times and Qibla | Batoul Apps Adhan, Hanafi Asr, Karachi/MWL/Umm al-Qura methods, five Afghan cities and manual world coordinates/time zones | Compare with a known local timetable using matching parameters. Test Kabul’s half-hour offset, a DST region, polar-day handling and rotation in landscape. |
| Hanafi guide | Offline original instructional notes on wudu, the two-unit prayer, additional units and Witr, with sources | A Hanafi teacher checks sequence, terminology, conditions and scope before a public release. |
| Hijri calendar | Month browsing with Gregorian and Hijri day numbers, selectable date, Umm al-Qura calculation and a local ±2-day adjustment | Compare month transitions, Ramadan and both Eid dates with a local calendar. The display follows the civil day and the selected adjustment. |

## Reader editions and navigation

Mushaf.kt reads the 604 page starts and 30 Juz starts from the bundled Tanzil metadata. Each page is the half-open interval from its first verse to the next page start. Page 604 ends at 114:6. No artificial verse division is introduced. A Juz or surah index selection opens the page containing the starting verse. Bookmarks reference this edition’s page numbers. The framed layout follows the reference image as a design direction, while exact line endings and pagination differ from that printed edition.

The Android text engine shapes the bundled Scheherazade New font using right-to-left paragraphs. The fitter measures candidate sizes against the available height and width. Ruled lines use the same text layout baselines. Enlarging above 100% in ten-point steps allows vertical scrolling. The translation action opens the first ayah of the current page in the bilingual reader. The default fit, warm amber and dark modes only affect the recitation page. Notification entry points preserve the two independent resume positions.

## Worship and developer content

Worship.kt groups existing Hisn entries by daily occasion. The afternoon group links to remembrance after Dhuhr or Asr and general dhikr. It makes no claim of a distinct afternoon litany. Six offline teaching illustrations accompany the written Hanafi wudu sequence. The Salah guide adapts to the selected obligatory prayer or Witr. It retrieves the Arabic recitation examples directly from the bundled Quran and Hisn records. Its scope is individual daily prayer. A separate founder screen uses the supplied portrait and an adapted first-person account of NOOR’s purpose.

## Components and ownership
The app uses a single Gradle application module. Android platform Views handle text selection, RTL direction, accessibility scaling and system controls. The main activity owns navigation and saved screen state. Reader and Hisn share the same read-only Catalog. Calendar, prayer and reminder UI live in their own source files. The INTERNET permission enables a user-initiated HTTPS timetable request. All scripture and guide content remains embedded. There is no account system, analytics SDK or remote content dependency.

| Layer | Reads | Produces and owns |
|---|---|---|
| Presentation | Route, saved position, Catalog and preferences | Today, Quran, Adhkar and Prayer bottom navigation. Details include Tasbeeh, calendar, guide and settings. Back restores the previous route. |
| Content repository | Original numbered Arabic, chapter metadata, original English and Pashto SQLite databases, processed Hisn index | Immutable lists of surahs, verses and chapters, loaded once per process away from the main thread. Both translations and Arabic are joined on a pair of integers. |
| Device services | Prayer location, method, local date, rotation-vector sensor and geomagnetic declination | Local prayer times, true-north bearing and a directional dial. A numeric bearing remains available without a sensor. |
| User state | Local SharedPreferences | Translation visibility, text size, last position, prayer location, daily counters, Tasbeeh totals and three independently configured reminder schedules. |
| Background delivery | AlarmManager, package and clock events, notification permission and channel settings | An inexact alarm for the next chosen local time. The receiver re-arms the relevant schedule and opens the designated screen on tap. |
| Build and verification | Pinned Gradle wrapper, Android plugin, Kotlin and Adhan versions, publisher edition hashes | Installable debug APK, offline corpus verification and JVM screen/data tests. GitHub Actions packages debug builds. |

### Content loading and integrity
1. Read the publisher’s numbered Arabic into a map keyed by (surah, ayah). Preserve all characters. Search operates on surah metadata, never on a rewritten canonical text.
2. Atomically copy both publisher databases from assets to versioned cache files, then open it read-only. Group its ordered rows by surah, retaining translation and footnotes.
3. Join to the Arabic map. Compare chapter counts against Tanzil metadata. A failed load shows a retry screen. The cache rebuilds after ordinary cache clearing.
4. Read Hisn as chapters and numbered entries. The exact Arabic wording remains separate from UI captions and counter state.
5. Run the independent Python verifier during release preparation and CI. Check the asset hashes and every key against the ordered chapter counts. Updating an edition requires reviewing its notices, incrementing the cache filename, refreshing hashes, then repeating the verification.

### Optional online timetable and SQLite

Prayer remains usable with no connection. Refresh from AlAdhan issues a single HTTPS GET to api.aladhan.com/v1/timings/DD-MM-YYYY using the selected coordinates, method, time zone and Hanafi school. Timetable.kt validates the returned date, method, school, time zone and six clock times before replacing a SQLite row. Date, coordinates, zone, method and school all participate in the lookup key. A saved response remains available after restart. A failed request leaves the local calculation or existing match in view. Records more than 45 days older than the fetched date are pruned. Users can switch back to the local calculation at any time.

### Prayer, time and notification behavior
The prayer calculation uses the **selected place’s** civil date and IANA time zone. Daily reading reminders use the **phone’s** clock, even if the selected prayer city is elsewhere. This lets a reader travel while keeping a saved reference city. Reminder delivery uses ordinary Android notifications and can be deferred by idle or battery-saving policies. Prayer times are calculated start times. The current release offers daily recitation, ayah and adhkar reminders. Compass readings depend on the phone's heading sensor and magnetic environment.

The daily verse is drawn from a fixed reference list. Date modulo list length picks the index. Its notification carries the actual reference, so opening yesterday’s notification still opens yesterday’s verse. The recitation reminder instead opens the saved reading position. Android controls the collapsed and lock-screen layout; longer passages expand and are always available in the app.

### Presentation and accessibility
The shared header uses pointed arch outlines and eight-point stars drawn on Canvas. Deep emerald, warm ivory and muted gold carry through the screens. The launcher icon and notification glyph use the same arch silhouette. The recitation surface has a double frame and a fine rule below each line. The translated reader uses plain text surfaces. The bundled Scheherazade New font covers Arabic and Pashto offline. Reading blocks explicitly request RTL, right alignment, selectable text and extra line spacing. Navigation follows the selected language. Android system notifications use the OS template and NOOR’s icon.

## Delivery roadmap
This source includes all feature areas above. The sequence below describes how Aryan Info-Tech can take the development build through a public release. Estimates assume one Android developer with access to a Pashto reader and a Hanafi reviewer; review turnaround can change the dates.

| Stage | Owner and estimated effort | Work and exit condition |
|---|---|---|
| 1. Content acceptance | Content editor + Pashto reviewer, 2–4 days | Verify attribution, publisher updates, original files and footnotes. Resolve Hisn digital reuse rights and record primary references/grades where available. Exit with signed-off editions. |
| 2. Reading and design pilot | Developer + 2–3 readers, 2–3 days | Try small and large phones, text scaling and TalkBack. Inspect combining marks and Pashto glyphs. Review long ayahs, note placement and the daily card. Exit after readers can find and resume a verse independently. |
| 3. Worship validation | Hanafi teacher + developer, 2–4 days | Cross-check local timetables, direction and printed prayer instructions. Record method differences and correct the guide through the same release process as content changes. |
| 4. Android reliability | Developer, 2–3 days | Physical-device testing on the minimum API and a modern Samsung. Exercise denied notifications, battery saver, reboot, system clock changes, rotation and missing compass hardware. Verify first-launch airplane mode. |
| 5. Store candidate | Aryan Info-Tech, 1–2 days after review | Choose and protect the release signing key, build a signed release AAB, review store declarations and screenshots, run a closed test, then promote the reviewed version. Keep debug builds for development. |

## Release checks and maintenance
Use the tests in the Feature contracts table for pilot sign-off. Record the device, API level, city, method, content edition and observed result. When a translation correction arrives, document its publisher version and compare the affected verses/notes before rebundling. Preserve (surah, ayah) preference keys so reading position and bookmarks survive updates. Keep the previous release and content hashes for diagnosis. On-device data stays in the app sandbox; uninstalling or clearing app data removes reading progress. The full library remains in the installed APK.

## Bilingual navigation and durable counters
Language.kt selects the edition, footnotes, number context and screen labels. The activity applies the chosen locale on recreation. The language preference belongs to the device. Scripture and formal publisher notices retain their original language. Book.kt indexes 132 chapter openings independently in the 159-page English and 302-page Pashto editions. It renders one PDF page at a time and remembers a position per language. The Pashto printed contents omit chapter 118; its heading appears on page 241.

Tasbeeh.kt saves the current count per phrase locally on each increment. Selecting a writable document grants persistent access to an external file. A single writer records snapshots in order. Restore reads the latest valid complete snapshot, including when the last record was interrupted. Local counters continue if a document becomes unavailable. Reinstalling requires selecting the saved document again. Day-specific invocation counters use a separate namespace.

## Acceptance tests for the update
Verify the launch credit and the Home language switch in English and Pashto. Review both translations of the same verse against QuranEnc. Open the first ayahs of surahs 1, 2, 9 and 112. Compare text before and after presentation breaks. Check swipe and button sound, muted turns, page limits, large text, dark and warm paper. From the chapter search, open chapter 27 in each published book. In Documents test a fresh backup, three phrase totals, process restart, uninstall, reinstall, restore, and revoked file access. Test notifications after changing language while the app is closed. Record physical-device results separately from JVM tests.
